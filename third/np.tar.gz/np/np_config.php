<?php
define( "NP_VERSION", "NP1.1.0");

?>