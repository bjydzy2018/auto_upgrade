<?php
include_once dirname(__FILE__).DIRECTORY_SEPARATOR ."np_db.class.php" ;


?>