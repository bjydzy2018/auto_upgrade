<?php

//为了新旧包含兼容，保留此文件，后续统一采用 np_xxx.class.php 的风格，针对ＰＨＰ类
include_once dirname(__FILE__).DIRECTORY_SEPARATOR ."np_db_mysql.class.php" ;

?>