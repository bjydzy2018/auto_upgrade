<?php
	/**
	 * User: yxt
	 * Date: 2016/3/29
	 * Time: 8:58
	 */

include_once dirname(__FILE__).'/np_db_mysql.class.php';
include_once dirname(__FILE__).'/np_db_mysqli.class.php';
include_once dirname(__FILE__).'/np_kv_cache_redis.class.php';
	if(defined('mysql_driver_type')&&strtolower(mysql_driver_type)==='mysqli')
	{
		class np_db_mysql_with_cache_parent extends np_db_mysqli_class
		{

		}
	}
	else
	{
		class np_db_mysql_with_cache_parent extends np_db_mysql_class
		{
		}
	}
	class np_db_mysql_with_cache extends np_db_mysql_with_cache_parent
	{
		private $db_query_cache_enabled=0;//db��ѯ�����Ƿ�����0�رգ�1����
		private $arr_cache_params=array();//db����������ã����ֻ������ӣ�����ʱ��֮�������
		public $str_cache_key='';//����key
		private $obj_kv_cache_redis=null;
		private $str_sql='';

		public function __construct ($config)
		{
			parent::__construct($config);
			if(defined('g_debug')&&g_debug==1)
			{
				foreach($config['db_cache_params_config'] as $key=>$val)
				{
					header("ng_db_query_cache_params_{$key}:{$val}");
				}
			}
			$this->arr_cache_params=$config['db_cache_params_config'];
			$arr_kv_cache_config=np_kv_cache_build_config(NP_KV_CACHE_TYPE_REDIS,1,$config['db_cache_config']);
			$this->obj_kv_cache_redis=np_kv_cache_factory_create($arr_kv_cache_config);
			$this->db_query_cache_enabled=$config['db_cache_params_config']['ng_cache_enable'];
		}

		public function enable_cache()
		{
			$this->db_query_cache_enabled=1;
		}

		public function disable_cache()
		{
			$this->db_query_cache_enabled=0;
		}

		/**
		 * 2016��3��29��17:35:25
		 * ��С��
		 * ��������key
		 * @param $str_sql sql���
		 *
		 * @return string
		 */
		private function __create_cache_key($str_sql)
		{
			$ng_api_cache_key=$this->arr_cache_params['ng_api_cache_key'];
			$ng_db_cache_key=$this->arr_cache_params['ng_db_cache_key'];
			$func=$this->arr_cache_params['func'];
			$this->str_cache_key=md5($ng_api_cache_key.$ng_db_cache_key.$func.$str_sql);
			return $this->str_cache_key;
		}

		/**
		 * 2016��3��29��17:35:50
		 * ���û���
		 * @param $str_sql sql���
		 * @param $mixed_val ���
		 *
		 * @return bool
		 */
		private function set_cache($str_sql,$mixed_val)
		{
			$bool_re=false;
			//������濪��
			if($this->db_query_cache_enabled)
			{
				$str_key=$this->__create_cache_key($str_sql);
				$bool_re = $this->obj_kv_cache_redis->set($str_key,$mixed_val,$this->arr_cache_params['ng_cache_time']);
			}
			return $bool_re;
		}

		/**
		 * 2016��3��29��17:35:50
		 * ��ȡ����
		 * @param $str_sql sql���
		 *
		 * @return bool
		 */
		private function get_cache($str_sql)
		{
			$bool_re=false;
			if($this->db_query_cache_enabled)
			{
				$str_key=$this->__create_cache_key($str_sql);
				$bool_re =  $this->obj_kv_cache_redis->get($str_key);
			}
			return $bool_re;
		}

		public function query ($sql)
		{
			$this->str_sql=$sql;

			$mixed_query_data = parent::query($sql);

			return $mixed_query_data;
		}

		public function get_query_result($is_free_after_get = TRUE)
		{
			//�������ǿˢ�£����ҿ����˻��濪��
			if(!$this->arr_cache_params['flush_db_cache'])
			{
				$mixed_data=$this->get_cache($this->str_sql);
				if($mixed_data)
				{
					if(defined('g_debug')&&g_debug==1)
					{
						header("db_query_cache_sql_cache_hit:sql[{$this->str_sql}]");
					}
					return $mixed_data;
				}
			}
			//��ǿˢ�»��߻�ȡ����ʧ�ܣ�������ݿ��
			$mixed_query_data=parent::get_query_result($is_free_after_get);
			if($mixed_query_data!==false)
			{
				$bool_re=$this->set_cache($this->str_sql,$mixed_query_data);
				if(defined('g_debug')&&g_debug==1)
				{
					if($bool_re)
					{
						header("dbquery_cache_set_success:sql[{$this->str_sql}]");
					}
					else
					{
						header("db_query_cache_set_fail:[{$this->str_sql}]");
					}
				}
			}
			return $mixed_query_data;
		}
	}