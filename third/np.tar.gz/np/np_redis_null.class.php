<?php

class np_redis_null_class {

    public function __construct($config = array())
    {

    }

    public function __call($name,$arguments)
    {
        return FALSE;
    }

    public function get_redis()
    {
        return $this;
    }

}
?>