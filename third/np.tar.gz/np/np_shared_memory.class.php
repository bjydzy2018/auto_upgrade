<?php
/**
 * User: fuyuan.shuai
 * Date: 2015/8/17
 * Time: 10:55
 * 仅在linux可用
 */
class np_shared_memory
{
    //共享内存的系统ID
    const SHM_SYSTEM_ID = 0xff00;
    //    全局配置存储SIZE，以M为单位
    const SHM_GLOBAL_SIZE = 1;
//    共享内存的分配空间，以M为单位
    const SHM_SIZE = 128;

    const SHM_WRITE_MODE = "write";

    const SHM_READ_MODE = "read";

    const SHM_KEY_MAX_SIZE = 1;

    private $keymap;

    private $shm_id = NULL;

    /**
     * @param $key_map KEY的定义MAP表
     * 格式
     * $key_map[0][key]=键名
     * $key_map[0][size]=键的最大内存分配
     * $key_map[0][desc]=键的说明
     * @param string $mode 模式时读还是写
     */
    public function open($key_map,$mode=self::SHM_READ_MODE)
    {
        if (!$this->check_valid())
        {
            return;
        }
        $this->keymap = $key_map;
        if ($mode == self::SHM_WRITE_MODE)
        {
            $this->shm_id = @shmop_open(self::SHM_SYSTEM_ID,"c",0755,(self::SHM_SIZE+self::SHM_GLOBAL_SIZE)*1024*1024);
        }else
        {
            $this->shm_id = @shmop_open(self::SHM_SYSTEM_ID,"a",0,0);
        }
    }

    public function check_valid()
    {
        if (function_exists("shmop_open"))
        {
            $bool  = strtoupper(substr(PHP_OS,0,3))==='WIN'?false:true;
            return $bool;
        }
        return false;
    }


    private function _set($data,$offset)
    {
        $size = mb_strlen($data, 'UTF-8');
        $size =sprintf('0x%06s', dechex($size));
        $r_data = $size."|#".$data;
        $bool = @shmop_write($this->shm_id,$r_data,$offset);
        return $bool;
    }

    private function _get($offset)
    {

        $datalen = shmop_read($this->shm_id,$offset,10);
        if (trim($datalen)=="")
        {
            return false;
        }
        $datalen = rtrim($datalen,"|#");
        $datalen = hexdec($datalen);
        $size = shmop_size($this->shm_id);
        $data = shmop_read($this->shm_id,$offset+10,$datalen);

        return $data;
    }


    private function __get_position($key)
    {
       $keymap = $this->keymap;
        $offset = 0;
        foreach ($keymap as $item)
        {
            if ($item["key"] == $key)
            {
                return $offset+self::SHM_GLOBAL_SIZE*1024*1024;
            }
            $offset = $offset + $item["size"]+10;
        }
        return false;
    }


    /**
     * @return mixed
     * status =array();
     * status[p]=partation使用情况
     * status[k]=key使用情况
     * status[p][s]=已经使用区块
     * status[p][n]=总的key数
     * status[k][$key][p]=单个key的数据缓存位置
     */
    public function status()
    {
        $global_data = $this->_get(0);
        return json_decode($global_data,true);
    }

    public function set($key,$value,$expire_time = 0)
    {
        if (!$this->check_valid())
        {
            return false;
        }
        $size = mb_strlen($value, 'UTF-8');
        if ($size > self::SHM_KEY_MAX_SIZE*1024*1024)
        {
            return false;
        }

        $pos = $this->__get_position($key);
        if ($pos===false)
        {
            return false;
        }
        if ($expire_time != 0)
        {
            $expire_datetime =  time()+$expire_time;
        }else{
            $expire_datetime = "0";
        }

        $expire_datetime = sprintf("%016d",$expire_datetime);
        $data = $expire_datetime.$value;
//        $data = array();
//        $data["d"] = $value;
//
//        if ($expire_time > 0)
//        {
//            $data["t"] = time()+$expire_time;
//        }
//        $data = json_encode($data);
        return $this->_set($data,$pos);
    }

    public function get($key)
    {
        if (!$this->check_valid())
        {
            return false;
        }
        $pos = $this->__get_position($key);
        if ($pos===false)
        {
            return false;
        }
        $data = $this->_get($pos);
        $expire_datetime = substr($data,0,16);
        if ((int)$expire_datetime != 0 and time() > (int)$expire_datetime)
        {
            return false;
        }
        $value = substr($data,16);
//        $data = json_decode($data,true);
//        if (time() > $data["t"])
//        {
//            return false;
//        }
//        return $data["d"];
        return $value;
    }

    public function clear($key)
    {
        $re = $this->get($key);
        if ($re !==  false)
        {
            $this->set($key,$re,-1);
        }
    }



    public function close()
    {
        if (!$this->check_valid())
        {
            return ;
        }
        @shmop_close($this->shm_id);
    }

} 