<?php
/**
 * 电信smgp协议
 * 此协议用于电信发送短信
 * Usege:
 * requie_once("<your path>/smgp.class.php");
 * $smgp = new Smgp();
 * $smgp->login();
 * $smgp->send_msg($msg, $phones, $opts);
 *
 * @Parmas
 * === Needs:
 * host:                发送短信主机IP
 * port:                发送短信主机端口
 * user:                认证客户身份证
 * password:            认证用户公有密锁
 * === Options:
 * logger_path          日志记录目录
 * logger_mode          日志记录方式
 * is_worker_mode       是否是工作流方式(#TODO 排期实现，本次版本中未实现)
 * msg_type             消息类型
 * need_report          是否需要返回报告
 * priority             优先级
 * servive_id           业务代码
 * fee_type             收费类型
 * fee_code             资费代码
 * msg_format           消息格式
 * vaild_time           短信有效期
 * at_time              发送时间
 * src_term_id          短信发送方号码
 * charge_term_id       计费号码
 *
 * @Author tom.chen <ziwei.chen@starcor.cn>
 * @create_date 2015-09-28 10:21:55
 */

namespace NpSmgp{
  define("LOCAL_LANG", 'zh_CN');
}

namespace {
if( !defined("SMGP_ROOT"))
    define("SMGP_ROOT", dirname(__FILE__).DIRECTORY_SEPARATOR."np_smgp".DIRECTORY_SEPARATOR);

if( !defined("SMGP_DEFAULT_LOG_PATH"))
    define("SMGP_DEFAULT_LOG_PATH", SMGP_ROOT."logs".DIRECTORY_SEPARATOR);

require_once(SMGP_ROOT."client.class.php");
use NpSmgp as SM;

class NpSmgp{
    // 短信发送失败即退出
    const FAILD_BREAK             = 1;
    //　短信发送失败重试
    const FAILD_RETRY             = 2;
    // 短信发送发送失败继续
    const FAILD_CONTINUE          = 3;
    // 短信发失败抛出错误，并结束程序
    const FAILD_THROW_ERROR       = 4;
    //　默认重试次数
    const DEFAULT_RETRY_TIMES     = 3;

    // =========================平台相关信息======================================
    private $host                 = '115.168.94.48';
    private $port                 = 8891;
    private $user                 = 'mykk';
    private $password             = 'MY.kk357';
    private $msg_single_limit     = 140;
    private $pre_sms_phones_limit = 99;
    private $worker               = null;
    private $_client              = null;
    // 短信发送机制
    // 参考: FAILD_BREAK, FAILD_RETRY, FAILD_CONTINUE, FAILD_THROW_ERROR
    private $send_mode            = self::FAILD_BREAK;
    private $send_retry_times     = self::DEFAULT_RETRY_TIMES;

    // =========================日志相关信息======================================
    private $logger           = null;
    private $logger_path      = SMGP_DEFAULT_LOG_PATH;
    private $logger_mode      = SM\Logger::LOG_MODE_DAILY;
    private $opts_keys_arr    = array('logger_path', 'logger_mode', 'msg_type', 'need_report', 'priority',
                                      'service_id', 'fee_type', 'fee_code', 'msg_format', 'vaild_time', 'at_time',
                                      'src_term_id', 'charge_term_id', 'product_id', 'send_mode', 'send_retry_times');

    // =========================短信发送相关配置(必选)=============================
    // 短消息所需的参数
    // #TODO 这里可以修改为外界可控制长度和类型的方式。
    public static $sms_params = array('msg_type', 'need_report', 'priority','service_id', 'fee_type', 'fee_code',
                                      'fixed_fee', 'msg_format', 'vaild_time', 'at_time', 'src_term_id', 'charge_term_id',
                                      'dest_term_id_count', 'dest_term_id', 'msg_length', 'msg_content', 'product_id');
    // 短消息类型
    private $msg_type         = SM\Code\MsgType::MT;
    /**
     * SP是否要求返回状态报告
     * 0: 不要求返回报告
     * 1: 要求返回报告
     **/
    private $need_report      = 1;
    // 短消息发送优先级
    private $priority         = SM\Code\Priority::LOWER_PRIORITY;
    // 业务代码
    private $service_id       = '';
    // 收费类型
    private $fee_type         = SM\Code\FeeType::FEE_FREE;
    // 资费代码
    private $fee_code         = '00';
    // 包月/封顶费
    private $fixed_fee        = '0000';
    // 短信格式
    private $msg_format       = SM\Code\MsgFormat::UCS2_ENCODING;
    // 短信有效期
    private $vaild_time       = '';
    // 定时发送时间
    private $at_time          = '';
    // 短信发送方号码
    private $src_term_id      = '10659202682';
    // 计费用户号码
    private $charge_term_id   = '';
    // 暂时没有使用
    private $product_id       = '112000000000000001032';

    public function __construct($host=null, $port=null, $user=null, $password=null, $opts=array()){
        if( !empty($host) )
            $this->host = $host;

        if( !empty($port) )
            $this->port = $port;

        if( !empty($user) )
            $this->user = $user;

        if( !empty($password) )
            $this->password = $password;

        // 处理可选参数赋值问题
        if( is_array($opts) ){
            foreach($opts as $key => $val){
                if( in_array($key, $opts_keys_arr) ){ $this->$key = $val; }
            }
        }
    }

    /**
     * 发送短信到客户手机
     * @param  string       $msg    短信内容
     * @param  array/string $phones 接受者手机号码（组）
     * @return boolean
     */
    public function send_msg($msg, $phones, $at_time = null){
        $message = new SM\Message( $msg, $this->msg_single_limit, $this->msg_format, ($logger = $this->get_logger()) );

        $opts = array_combine( self::$sms_params, array_fill(0, count(self::$sms_params), null) );
        foreach( self::$sms_params as $param ){
          if( isset($this->$param) ){
            $opts[$param] = $this->$param;
          }
        }

        if( !empty($at_time) ){
          $opts['at_time'] = $at_time;
        }

        $respes      = [];
        $retry_times = 0;

        while( list($single_msg, $step, $total) = $message->get_single_message() ){
            if( empty($single_msg) ) { break; }

            $resp = $this->send_sms($single_msg, $opts, $phones, $total, $step);

            switch ($this->send_mode) {
              //　失败则退出
              case self::FAILD_BREAK:
                array_push($respes, $resp);
                if( !$resp[0] ){ return $respes; }
                break;
              //　失败再重试
              case self::FAILD_RETRY:
                if( !$resp[0] ){
                  if( $retry_times < $this->send_retry_times){
                    $message->rollback();
                    $retry_times++;
                  }
                  else{
                    array_push($respes, $resp);
                    return $respes;
                  }
                }
                else{
                  array_push($respes, $resp);
                  $retry_times = 0;
                }
              break;
              // 失败则抛出错误
              case self::FAILD_THROW_ERROR:
                throw new Exception("发送短信失败: 请检查发送日志.", 1);
                die;
              break;
              // 失败后继续下条短信
              default:
                array_push($respes, $resp);
            }
        }

        return $respes;
    }

    private function send_sms($single_msg, $opts, $phones, $total, $step){
      //　如果时长短信则需设置可选参数udhi, pktotal, pk_number
      if( $total > 1 ){
        $opts = array_merge($opts, ['tp_udhi'   => [1, $total, $step]]);
      }
      return $this->get_client()->send_sms($single_msg, $opts, $phones);
    }

    /**
     * 设置日志目录及日志类型
     * @param string $path 日志目录地址
     * @param integer $mode 日志类型
     */
    public function set_log_path($path, $mode=SM\Logger::LOG_MODE_DAILY){
      if( !is_dir($path) ){
        throw new Exception("日志目录地址不存在，请先自建目录。");
        return false;
      }

      $this->logger_path = $path;
      $this->logger_mode = $mode;
    }


    private function set_mutil_msg_options($send_step, $total_sms_count, &$sms_opts){
      $udhi      = array(SM\Code\OptionParams::TP_UDHI,   1);
      $pk_total  = array(SM\Code\OptionParams::PK_TOTAL,  $total_sms_count);
      $pk_number = array(SM\Code\OptionParams::PK_NUMBER, $send_step);
      $sms_opts['options'] = array($udhi, $pk_total, $pk_number);
    }

    /**
     * 获取实例对象内的logger实例对象，如果不存在实例对象则自动创建一个logger实例对象。
     * @return logger
     */
    private function get_logger(){
        if( $this->logger instanceof SM\Logger )
            return $this->logger;

        return ( $this->logger = new SM\Logger( $this->logger_path, $this->logger_mode) );
    }

    /**
     * 获取登陆后的客户端
     * @return boolean/client
     */
    private function get_client(){
        if( $this->_client instanceof SM\Client )
            return $this->_client;

        $client = new SM\Client( $this->host, $this->port, $this->user, $this->password, 1 ,
                                 SM\Code\LoginMode::LOGIN, 1, $this->get_logger() );
        if( $login_result = $client->login() ){
            if( $login_result[0] ){
                return ($this->_client = $client);
            }
            else{ throw new Exception( "登陆电信网管失败: {$login_result[3]}." ); }
        }
        else{ throw new Exception( "登陆电信网管失败: 未知原因." ); }
    }

    /**
     * 魔法方法： 设置指定范围内存在的变量内容
     * @param string $key 变量名
     * @param string $val 变量值
     */
    public function __set($key, $val){
        if( in_array($key, $this->opts_keys_arr) ){
            switch( $key ){
              case 'logger_path':
                $this->set_log_path($val);
              break;
              default:
                $this->$key = $val;
            }
        }
    }

    /**
     * 魔法方法: 获取指定范围内存在的变量内容
     * @param  string $key 变量名
     * @return void 返回该变量的值
     */
    public function __get($key){
        if( in_array($key, $this->opts_keys_arr) ){
            return $this->$key;
        }
    }
}

// namespace end
}