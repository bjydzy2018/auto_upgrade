<?php
/**
 * 中国电信SMGP协议
 * 生成对应的客户端
 *
 * @Usege:
 * requie_once("<your path>/npsmgp/client.class.php");
 *
 * use NpSmgp;
 * $client = new Client(string $host, int $prot, string $client_id,
 *                      string $client_passwd, string $spid, int $login_mode,
 *                      int display_mode
 *                      )
 *
 * $client->login();
 * $client->send_msg(string $message_body, int $mobile_number);
 * $client->send_multi_msg(string $message_body, int $mobile_number, \
 *                           [int $mobile_number]...);
 * $client->logout();
 *
 * @Author:      tom.chen <ziwei.chen@starcor.cn>
 * @DateTime:    2015-09-23 11:07:54
 */
namespace NpSmgp;

$global_sequence_id = 0;
if( !defined('LOCAL_LANG') ){
    define("LOCAL_LANG", 'zh_CN');
}

define("CLASS_ROOT_PATH", dirname(__FILE__).DIRECTORY_SEPARATOR);
//载入所有的协议code
require_once(CLASS_ROOT_PATH.'code'.DIRECTORY_SEPARATOR."include_code.php");
require_once(CLASS_ROOT_PATH.'i18n.class.php');
require_once(CLASS_ROOT_PATH.'logger.class.php');
require_once(CLASS_ROOT_PATH.'pack_sender.class.php');
require_once(CLASS_ROOT_PATH.'connect.class.php');
require_once(CLASS_ROOT_PATH.'result.class.php');
require_once(CLASS_ROOT_PATH.'message.class.php');

class Client{
    private $_host         = '';
    private $_port         = 0;
    private $_client_id    = 0;
    private $_client_pwd   = '';
    private $_client_ver   = 0;
    private $_login_mode   = 0;
    private $_display_mode = 1;
    private $_spid         = '';
    private $_connect      = NULL;
    private $_logger       = NULL;

    public function __construct( $host, $port, $client_id, $client_pwd, $spid, $login_mode=Code\LoginMode::LOGIN,
                                 $display_mode = 1, Logger &$logger = NULL ){

        if ( !is_null($logger) ){
            $this->_logger = $logger;
        }
        else{
            $this->_logger = new Logger();
        }

        // 首先判断是否有短信网关ip和端口
        if( !empty($host) && is_int($port) ){
            $this->_host = $host;
            $this->_port = $port;
        }
        else{
            $this->_logger->logging(I18n::get(I18n::NOT_INPUT_HOST_OR_PORT, LOCAL_LANG),
                                    Logger::ERROR, $host, $port);
            return false;
        }

        if( !empty($client_id) && !empty($client_pwd) && is_int($spid) ){
            $this->_client_id  = $client_id;
            $this->_client_pwd = $client_pwd;
            $this->_spid       = $spid;
        }
        else{
            $this->_logger->logging(I18n::get(I18n::CLIENT_ID_PASSWD_EMPTY, LOCAL_LANG),
                                    Logger::ERROR);
            return false;
        }

        if( !empty($login_mode) ){
            $this->_login_mode = (int) $login_mode;
        }
        else{
            $this->_login_mode = NpCode\LoginMode::LOGIN;
        }

        if( !empty($display_mode) ){
            $this->_display_mode = (int) $display_mode;
        }

        $this->create_connect();
    }

    /**
     * 登录客户端
     * @return array
     */
    public function login(){
        $responses   = $this->pack_sender()->login($this->_client_id, $this->_client_pwd);
        if( $responses ){
            return $responses;
        }
        return false;
    }

    public function send_sms($msg, $opts, $phones){
        if( is_array($phones) ){
            $responses   = $this->pack_sender()->send_multi_sms_by_array($msg, $opts, $phones);
        }
        else{
            $responses   = $this->pack_sender()->send_single_sms($msg, $opts, $phones);
        }

        if( $responses ){
            return $responses;
        }
        return false;
    }

    private function pack_sender(){
        if( !($this->_connect instanceof Connect) ){
            $this->create_connect();
        }

        if( !$this->_connect->conn_status ){
            throw new \Exception(I18n::get(I18n::CAN_NOT_CONNECT_SMGP, LOCAL_LANG), 1);
            die;
        }

        return new PackSender($this->_connect, $this->_client_ver, $this->_logger);
    }

    private function create_connect(){
        $this->_connect = new Connect($this->_host, $this->_port, $this->_logger);
    }
}
