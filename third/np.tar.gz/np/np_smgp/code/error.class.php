<?php
/**
 * 中国电信SMGP协议
 * 错误消息码表
 *
 * @Usege:
 * require_once("<your path>/np_smgp/error.class.php");
 * use namespace NpSmgp\Code;
 *
 * $msg = NpSmgp\Code\Error::get_error_msg(int);
 *
 * @Author:      tom.chen <ziwei.chen@starcor.cn>
 * @DateTime:    2015-09-21 16:49:01
 */

namespace NpSmgp\Code;

class Error{
    // 成功
    const SUCCESS                  = 0;
    // 用户不能通信
    const USER_CAN_NOT_BE_REACH    = 1;
    // 用户忙
    const USER_IS_BUSY             = 2;
    // 终端无此部件号
    const TERMINAL_HAS_NOT_PART_NO = 3;
    // 非法用户
    const ILLEGAL_USER             = 4;
    // 用户在黑名单内
    const USER_IN_BLACKLIST        = 5;
    // 系统错误
    const SYSTEM_WRONG             = 6;
    // 用户内存满
    const USER_SDCARD_NO_LAVE      = 7;
    // 非信息终端
    const NOT_INFO_TERMINAL        = 8;
    // 数据错误
    const DATA_IS_WRONG            = 9;
    // 数据丢失
    const DATA_IS_MISSED           = 10;
    // 未知错误
    const UNKOWN_ERROR             = 999;

    public static function get_error_msg_by_code(int $code){
        switch($code){
            case self::SUCCESS:
                return "成功";
            case self::USER_CAN_NOT_BE_REACH:
                return "用户不能通信";
            case self::USER_IS_BUSY:
                return "用户忙";
            case self::TERMINAL_HAS_NOT_PART_NO:
                return "终端无此部件号";
            case self::ILLEGAL_USER:
                return "非法用户";
            case self::USER_IN_BLACKLIST:
                return "用户在黑名单内";
            case self::SYSTEM_WRONG:
                return "系统错误";
            case self::USER_SDCARD_NO_LAVE:
                return "用户内存满";
            case self::NOT_INFO_TERMINAL:
                return "非信息终端";
            case self::DATA_IS_WRONG:
                return "数据错误";
            case self::DATA_IS_MISSED:
                return "数据丢失";
            case self::UNKOWN_ERROR:
                return "未知错误";
            default:
                return "未知错误(非协议)";
        }
    }
}