<?php
/**
 * 中国电信SMGP协议
 * 包含所有code文件
 *
 * @Usege:
 * require_once("<your path>/np_smgp/include_code.php");
 *
 * $status = NpCode\Status::get_status_msg(int);
 *
 * @Author:      tom.chen <[<email adress>]ziwei.chen@starcor.cn>
 * @DateTime:    2015-09-23 10:22:43
 */
$_code_dir_path = dirname(__FILE__).DIRECTORY_SEPARATOR;
require_once($_code_dir_path."error.class.php");
require_once($_code_dir_path."fee_type.class.php");
require_once($_code_dir_path."login_mode.class.php");
require_once($_code_dir_path."msg_format.class.php");
require_once($_code_dir_path."msg_type.class.php");
require_once($_code_dir_path."priority.class.php");
require_once($_code_dir_path."request_id.class.php");
require_once($_code_dir_path."status.class.php");
require_once($_code_dir_path."option_params.class.php");

use NpSmgp\Code as NpCode;

unset($_code_dir_path);