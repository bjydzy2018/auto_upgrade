<?php
/**
 * 中国电信SMGP协议
 * 登录模式
 *
 * @Useage:
 * requre_once("<your path>/np_smgp/login_mode.class.php");
 * use namespace NpSmgp\Code;
 *
 * $send_mode = NpSmgp\Code\LoginMode::Send;
 *
 * @author          tom.chen <ziwei.chen@starcor.cn>
 * @created_date:   2015-09-21 16:16
 */

namespace NpSmgp\Code;

class LoginMode{
    // 发送短信
    const LOGIN    = 1;
    // 接受短信
    const RECEIVE  = 2;
    // 收发短信
    const TRANSMIT = 3;
    // 未知的
    const UNKOWN   = 0;
}