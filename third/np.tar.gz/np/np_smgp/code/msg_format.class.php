<?php
/**
 * 中国电信SMGP协议
 * 短消息内容体的编码格式
 *
 * @Usege:
 * require_once("<your path>/np_smgp/msg_format.class.php");
 * use namespace NpSmgp\Code;
 *
 * $status = NpSmgp\Code\MsgFormat::MO;
 *
 * @Author:      tom.chen <ziwei.chen@starcor.cn>
 * @DateTime:    2015-09-22 15:59:42
 */
namespace NpSmgp\Code;

class MsgFormat{
    // ASCII编码
    const ASCII_ENCODING             = 0;
    // 消息写卡操作
    const MSG_WRITE_TO_CARD_ENCODING = 3;
    // 二进制编码
    const BINARY_ENCODING            = 4;
    // UCS2编码
    const UCS2_ENCODING              = 8;
    // GB18030编码
    const GB18030_ENCODING           = 15;
    // (U)SIM相关消息
    const SIM_ENCODING               = 246;

    /**
     * 获取编码对应的显示名
     * @param  int $formart_code 字符串编码对应数字
     * @return string  字符串编码名
     */
    public static function get_format_encoding($format_code){
        switch((int) $format_code){
            case self::ASCII_ENCODING:
                return "ASCII";
            case self::BINARY_ENCODING:
                return "BINARY";
            case self::UCS2_ENCODING:
                return "UCS-2BE";
            case self::GB18030_ENCODING:
                return "GB18030";
            default:
                return "UTF-8";
        }
    }
}