<?php
/**
 * 中国电信SMGP协议
 * 消息类型
 *
 * @Usege:
 * require_once("<your path>/np_smgp/msg_type.class.php");
 * use namespace NpSmgp\Code;
 *
 * $status = NpSmgp\Code\MsgType::MO;
 *
 * @Author:      tom.chen <ziwei.chen@starcor.cn>
 * @DateTime:    2015-09-22 14:48:37
 */

namespace NpSmgp\Code;

class MsgType{
    //终端发给SP
    const MO  = 0;
    //SP发给终端，包括WEB上发送的点对点短消息
    const MT  = 6;
    //点对点短消息
    const P2P = 7;
}