<?php
/**
 * 中国电信SMGP协议
 * 可選參數
 *
 * @Usege:
 * require_once("<your path>/np_smgp/option_params.class.php");
 * use namespace NpSmgp\Code;
 *
 * $status = NpSmgp\Code\OptionParams::TP_UDHI;
 *
 * @Author:      tom.chen <ziwei.chen@starcor.cn>
 * @DateTime:    2015-10-15 15:27:47
 */

namespace NpSmgp\Code;

class OptionParams{
    // GSM协议类型
    const TP_PID             = 0x0001;
    // GSM协议类型
    const TP_UDHI            = 0x0002;
    const LINK_ID            = 0x0003;
    const CHARGE_USER_TYPE   = 0x0004;
    const CHARGE_TERM_TYPE   = 0x0005;
    const CHARGE_TERM_PSEUDO = 0x0006;
    const DEST_TERM_TYPE     = 0x0007;
    const DEST_TERM_PSEUDO   = 0x0008;
    const PK_TOTAL           = 0x0009;
    const PK_NUMBER          = 0x000A;
    const SUBMIT_MSG_TYPE    = 0x000B;
    const SPDEAL_RESLT       = 0x000C;
    const SRC_TERM_TYPE      = 0x000D;
    const SRC_TERM_PSEUDO    = 0x000E;
    const NODES_COUNT        = 0x000F;
    const MSG_SRC            = 0x0010;
    const SRC_TYPE           = 0x0011;
    const MSERVICE_ID        = 0x0012;

}