<?php
/**
 * 中国电信SMGP协议
 * 优先级
 *
 * @Usege:
 * require_once("<your path>/np_smgp/priority.class.php");
 * use namespace NpSmgp\Code;
 *
 * $status = NpSmgp\Code\Priority::LOWER_PRIORITY;
 *
 * @Author:      tom.chen <ziwei.chen@starcor.cn>
 * @DateTime:    2015-09-22 15:25:55
 */
namespace NpSmgp\Code;

class Priority{
    // 低优先级
    const LOWER_PRIORITY   = 0;
    // 普通优先级
    const NORMAL_PRIORITY  = 1;
    // 较高优先级
    const HIGHER_PRIORITY  = 2;
    // 高优先级
    const HIGHEST_PRIORITY = 3;
}