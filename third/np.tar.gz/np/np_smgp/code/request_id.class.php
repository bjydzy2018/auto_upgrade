<?php
/**
 * 中国电信SMGP协议
 * 请求协议的各种请求ID，16进制对象。
 *
 * @Useage:
 * include_once("<your path>/np_smgp/request_id.class.php");
 * use namespace NpSmgp\Code;
 *
 * $login_request_id = NpSmgp\Code\RequestId::Login;
 *
 * @author:         tom.chen <ziwei.chen@starcor.cn>
 * @created_date:   2015-09-21 16:07
 **/

namespace NpSmgp\Code;

class RequestId{
    // 客户端登录
    const LOGIN                     = 0x00000001;
    // 客户端登录应答
    const LOGIN_RESP                = 0x80000001;
    // 提交短消息
    const SUBMIT                    = 0x00000002;
    // 提交短消息应答
    const SUBMIT_RESP               = 0x80000002;
    // 下发短消息
    const DELIVER                   = 0x00000003;
    // 下发短消息应答
    const DELIVER_RESP              = 0x80000003;
    // 链路检测
    const ACTIVE_TEST               = 0x00000004;
    // 链路检测应答
    const ACTIVE_TEST_RESP          = 0x80000004;
    // 短消息前转
    const FORWARD                   = 0x00000005;
    // 短消息前转应答
    const FORWARD_RESP              = 0x80000005;
    // 退出请求
    const EXIT_RQ                   = 0x00000006;
    // 退出应答
    const EXIT_RESP                 = 0x80000006;
    // SP统计查询
    const QUERY                     = 0x00000007;
    // SP统计查询应答
    const QUERY_RESP                = 0x80000007;
    // 查询TE路由
    const QUERY_TE_ROUTE            = 0x00000008;
    // 查询TE路由应答
    const QUERY_TE_ROUTE_RESP       = 0x80000008;
    // 查询SP路由
    const QUERY_SP_ROUTE            = 0x00000009;
    // 查询SP路由应答
    const QUERY_SP_ROUTE_RESP       = 0x80000009;
    // 扣款请求(用于预付费系统，参见增值业务计费方案)
    const PAYMENT_REQUEST           = 0x0000000A;
    // 扣款请求响应(用于预付费系统，参见增值业务计费方案，下同)
    const PAYMENT_REQUEST_RESP      = 0x8000000A;
    // 扣款确认(用于预付费系统，参见增值业务计费方案)
    const PAYMENT_AFFIRM            = 0x0000000B;
    // 扣款确认响应(用于预付费系统，参见增值业务计费方案)
    const PAYMENT_AFFIRM_RESP       = 0x8000000B;
    // 查询用户状态(用于预付费系统，参见增值业务计费方案)
    const QUERY_USERSTATE           = 0x0000000C;
    // 查询用户状态响应(用于预付费系统，参见增值业务计费方案)
    const QUERY_USERSTATE_RESP      = 0x8000000C;
    // 获取所有终端路由
    const GET_ALL_TE_ROUTE          = 0x0000000D;
    // 获取所有终端路由应答
    const GET_ALL_TE_ROUTE_RESP     = 0x8000000D;
    // 获取所有SP路由
    const GET_ALL_SP_ROUTE          = 0x0000000E;
    // 获取所有SP路由应答
    const GET_ALL_SP_ROUTE_RESP     = 0x8000000E;
    // SMGW向GNS更新终端路由
    const UPDATE_TE_ROUTE           = 0x0000000F;
    // SMGW向GNS更新终端路由应答
    const UPDATE_TE_ROUTE_RESP      = 0x8000000F;
    // SMGW向GNS更新SP路由
    const UPDATE_SP_ROUTE           = 0x00000010;
    // SMGW向GNS更新SP路由应答
    const UPDATE_SP_ROUTE_RESP      = 0x80000010;
    // GNS向SMGW更新终端路由
    const PUSH_UPDATE_TE_ROUTE      = 0x00000011;
    // GNS向SMGW更新终端路由应答
    const PUSH_UPDATE_TE_ROUTE_RESP = 0x80000011;
    // GNS向SMGW更新SP路由
    const PUSH_UPDATE_SP_ROUTE      = 0x00000012;
    // GNS向SMGW更新SP路由应答
    const PUSH_UPDATE_SP_ROUTE_RESP = 0x80000012;
    // 未知的，保留的
    const UNKOWN                    = 0x00000000;
}