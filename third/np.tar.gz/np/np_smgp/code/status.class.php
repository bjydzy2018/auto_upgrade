<?php
/**
 * 中国电信SMGP协议
 * 请求返回结果。响应包用来向请求包返回成功信息或者失败原因
 * @Useage:
 * require_once("<your path>/np_smgp/status.class.php");
 * use namespace NpSmgp;
 *
 * //获取状态码
 * $status = NpSmgp\Code\Status::SUCESS;
 * //获取状态消息
 * $msg_str = NpSmgp\Code\Status::get_status_msg(int);
 *
 * @author tom.chen <ziwei.chen@starcor.cn>
 * @created_date: 2015-09-21 16:49:01
 */

namespace NpSmgp\Code;

class Status{
    // 成功
    const SUCCESS                           = 0;
    // 系统忙
    const SYSTEM_IS_BUSY                    = 1;
    // 超过最大连接数
    const OVERLOAD_MAX_CONNECTS             = 2;

    // 消息结构错误
    const ERROR_MESSAGE_STRUCT              = 10;
    // 命令字错
    const ERROR_COMMAND                     = 11;
    // 序号重复
    const DUPLICATE_INDEX                   = 12;

    // Ip地址错误
    const ERROR_IP_ADDR                     = 20;
    // 认证错
    const ERROR_AUTH                        = 21;
    // 版本太高
    const VERSION_IS_2HIGH                  = 22;

    // 非法消息类型
    const ILLEGAL_MSG_TYPE                  = 30;
    // 非法优先级
    const ILLEGAL_PRIORITY                  = 31;
    // 非法资费类型
    const ILLEGAL_FEE_TYPE                  = 32;
    // 非法资费代码
    const ILLEGAL_FEE_CODE                  = 33;
    // 非法短信格式
    const ILLEGAL_MSG_FORMAT                = 34;
    // 非法时间格式
    const ILLEGAL_TIME_LENGTH               = 35;
    // 非法短消息长度
    const ILLEGAL_MSG_LENGTH                = 36;
    // 有效期已过
    const EXPIRED_VALIDITY                  = 37;
    // 非法查询类别
    const ILLEGAL_QUERY_TYPE                = 38;
    // 路由错误
    const ERROR_ROUTER                      = 39;
    // 非法包月费/封顶费
    const ILLEGAL_FIXED_FEE                 = 40;
    // 非法更新类型
    const ILLEGAL_UPDATE_TYPE               = 41;
    // 非法路由编号
    const ILLEGAL_ROUTE_ID                  = 42;
    // 非法服务代码
    const ILLEGAL_SERVICE_ID                = 43;
    // 非法有效期
    const ILLEGAL_VALID_TIME                = 44;
    // 非法定时发送时间
    const ILLEGAL_AT_TIME                   = 45;
    // 非法发送用户号码
    const ILLEGAL_SRC_TERM_ID               = 46;
    // 非法接收用户号码
    const ILLEGAL_DEST_TERM_ID              = 47;
    // 非法计费用户号码
    const ILLEGAL_CHARGE_TERM_ID            = 48;
    // 非法SP服务代码
    const ILLEGAL_SP_CODE                   = 49;

    // 非法源网关代码
    const ILLEGAL_SRC_GATEWAY_ID            = 56;
    // 非法查询号码
    const ILLEGAL_QUERY_TERM_ID             = 57;
    // 没有匹配路由
    const  COUND_NOT_MATCH_ROUTER           = 58;
    // 非法SP类型
    const ILLEGAL_SP_TYPE                   = 59;
    // 非法上一条路由编号
    const ILLEGAL_LAST_ROUTE_ID             = 60;
    // 非法路由类型
    const ILLEGAL_ROUTE_TYPE                = 61;
    // 非法目标网关代码
    const ILLEGAL_DEST_GATEWAY_ID           = 62;
    // 非法目标网关IP
    const ILLEGAL_DEST_GATEWAY_IP           = 63;
    // 非法目标网关端口
    const ILLEGAL_DEST_GATEWAY_PORT         = 64;
    // 非法路由号码段
    const ILLEGAL_TERM_RANGE_ID             = 65;
    // 非法终端所属省代码
    const ILLEGAL_PROVINCE_CODE             = 66;
    // 非法用户类型
    const ILLEGAL_USER_TYPE                 = 67;
    // 本节点不支持路由更新
    const NOT_SUPPORT_UPDATE_ROUTER_ON_NODE = 68;
    // 非法SP企业代码
    const ILLEGAL_SP_ID                     = 69;
    // 非法SP接入类型
    const ILLEGAL_SP_ACCESS_TYPE            = 70;
    // 路由信息更新失败
    const FAILD_UPDATE_INFOMATION_ROUTER    = 71;
    // 非法时间戳
    const ILLEGAL_TIME                      = 72;
    // 非法业务代码
    const ILLEGAL_M_SERVICE_ID              = 73;
    // SP禁止下发时段
    const NO_SP_ISSUED_TIME                 = 74;
    // SP发送超过日流量
    const SP_MORE_THAN_DAILY_FLOW           = 75;
    // SP帐号过有效期
    const SP_ACCOUNT_EXPIRED                = 76;

    public static function get_status_msg($code){
        switch($code){
            case self::SUCCESS:
                return "成功";
            case self::SYSTEM_IS_BUSY:
                return "系统忙";
            case self::OVERLOAD_MAX_CONNECTS:
                return "超过最大连接数";
            case self::ERROR_MESSAGE_STRUCT:
                return "消息结构错";
            case self::ERROR_COMMAND:
                return "命令字错";
            case self::DUPLICATE_INDEX:
                return "序列号重复";
            case self::ERROR_IP_ADDR:
                return "IP地址错";
            case self::ERROR_AUTH:
                return "认证错";
            case self::VERSION_IS_2HIGH:
                return "版本太高";
            case self::ILLEGAL_MSG_TYPE:
                return "非法消息类型";
            case self::ILLEGAL_PRIORITY:
                return "非法优先级";
            case self::ILLEGAL_FEE_TYPE:
                return "非法资费类型";
            case self::ILLEGAL_FEE_CODE:
                return "非法资费代码";
            case self::ILLEGAL_MSG_FORMAT:
                return "非法短信格式";
            case self::ILLEGAL_TIME_LENGTH:
                return "非法时间格式";
            case self::ILLEGAL_MSG_LENGTH:
                return "非法短消息长度";
            case self::EXPIRED_VALIDITY:
                return "有效期已过";
            case self::ILLEGAL_QUERY_TYPE:
                return "非法查询类别";
            case self::ERROR_ROUTER:
                return "路由错误";
            case self::ILLEGAL_FIXED_FEE:
                return "非法包月费或封顶费";
            case self::ILLEGAL_UPDATE_TYPE:
                return "非法更新类型";
            case self::ILLEGAL_ROUTE_ID:
                return "非法路由编号";
            case self::ILLEGAL_SERVICE_ID:
                return "非法服务代码";
            case self::ILLEGAL_VALID_TIME:
                return "非法有效期";
            case self::ILLEGAL_AT_TIME:
                return "非法定时发送时间";
            case self::ILLEGAL_SRC_TERM_ID:
                return "非法发送用户号码";
            case self::ILLEGAL_DEST_TERM_ID:
                return "非法接收用户号码";
            case self::ILLEGAL_CHARGE_TERM_ID:
                return "非法计费用户号码";
            case self::ILLEGAL_SP_CODE:
                return "非法SP服务代码";
            case self::ILLEGAL_SRC_GATEWAY_ID:
                return "非法源网关代码";
            case self::ILLEGAL_QUERY_TERM_ID:
                return "非法查询号码";
            case self:: COUND_NOT_MATCH_ROUTER:
                return "不能匹配路由";
            case self::ILLEGAL_SP_TYPE:
                return "非法SP类型";
            case self::ILLEGAL_LAST_ROUTE_ID:
                return "非法上一条路由编号";
            case self::ILLEGAL_ROUTE_TYPE:
                return "非法路由类型";
            case self::ILLEGAL_DEST_GATEWAY_ID:
                return "非法目标网关代码";
            case self::ILLEGAL_DEST_GATEWAY_IP:
                return "非法目标网关IP";
            case self::ILLEGAL_DEST_GATEWAY_PORT:
                return "非法目标网关端口";
            case self::ILLEGAL_TERM_RANGE_ID:
                return "非法路由号码段";
            case self::ILLEGAL_PROVINCE_CODE:
                return "非法终端所属省代码";
            case self::ILLEGAL_USER_TYPE:
                return "非法用户类型";
            case self::NOT_SUPPORT_UPDATE_ROUTER_ON_NODE:
                return "本节点不支持路由更新";
            case self::ILLEGAL_SP_ID:
                return "非法SP企业代码";
            case self::ILLEGAL_SP_ACCESS_TYPE:
                return "非法SP接入类型";
            case self::FAILD_UPDATE_INFOMATION_ROUTER:
                return "路由信息更新失败";
            case self::ILLEGAL_TIME:
                return "非法时间戳";
            case self::ILLEGAL_M_SERVICE_ID:
                return "非法业务代码";
            case self::NO_SP_ISSUED_TIME:
                return "SP禁止下发时段";
            case self::SP_MORE_THAN_DAILY_FLOW:
                return "SP发送超过日流量";
            case self::SP_ACCOUNT_EXPIRED:
                return "SP帐号过有效期";
            default:
                return "未知错误";
        }
    }
}