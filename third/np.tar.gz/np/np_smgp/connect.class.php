<?php
/**
 * 中国电信SMGP协议
 * 连接远程消息网关
 *
 * @Usege:
 * [Usege]
 *
 * @Author:      tom.chen <ziwei.chen@starcor.cn>
 * @DateTime:    2015-09-24 13:59:33
 */

namespace NpSmgp;

class Connect{
    private $_socket       = null;
    private $_host         = null;
    private $_port         = null;
    private $logger        = null;

    private $_conn_domain  = AF_INET;
    private $_conn_type    = SOCK_STREAM;
    private $_conn_proto   = 0;
    private $_conn_timeout = 60;
    private $_retry_times  = 3;

    public $conn_status    = true;

    public function __construct($host, $port, Logger &$logger, $retry=3){
        if( empty($logger) ){
            throw new \Exception(I18n::get(I18n::CONNET_NEED_LOGGER, LOCAL_LANG));
            die;
        }
        else{ $this->logger = $logger; }

        if( empty($host) || empty($port) ){
            $this->logger->logging(I18n::get(I18n::CONNECT_NEED_HOST_PORT, LOCAL_LANG), Logger::ERROR);
            return false;
        }
        else{
            $this->_host = $host;
            $this->_port = $port;
        }

        $this->_retry_times = (int) $retry;

        $times = 0;
        while( !($conn = $this->conn()) && $this->_retry_times > $times ){ $times++; }

        // 如果重试$this->_retry_times(3)次还不能链接到socket服务器则将链接状态设置为false
        if( !$conn ){ $this->conn_status = false; }
    }

    /**
     * 获取当前socket流对象
     * @return socket 对象
     */
    public function get_conn(){
        return $this->_socket;
    }

    /**
     * 从socket流中读取指定长度的数据
     * @param integer $len 读取数据长度
     * @return binary 取得的二进制数据
     */
    public function read($len){
        if( $len < 1 )
            $this->logger->logging(I18n::get(I18n::READ_PACKAGE_IS_ZORE, LOCAL_LANG), Log\Logger::WARNNING);

        $bin = socket_read($this->_socket, $len);
        if( false === $bin ){
            $this->logger->login(I18n::get(I18n::READ_MESSAGE, LOCAL_LANG).socket_strerror(socket_last_error()),
                                 Log\Logger::FAILD);
        }

        return $bin;
    }

    /**
     * 发送二进制数据（写入socket流中）
     * @param binary $message_data 消息二进制数据流
     * @return boolean
     */
    public function send($message_data){
        if( $this->_socket ){
            $result = socket_write($this->_socket, $message_data);
            if( $result ){
               return $this;
            }
            else{
                $this->logger->logging(I18n::get(I18n::SEND_MESSAGE, LOCAL_LANG).socket_strerror(socket_last_error()),
                                       Log\Logger::FAILD);
            }
        }
        return false;
    }

    /**
     * 连接smgp协议网关
     * @return void
     */
    private function conn(){
        $this->_socket = socket_create($this->_conn_domain, $this->_conn_type, $this->_conn_proto);

        if( !$this->_socket ){
            $this->logger->logging(I18n::get(I18n::CREATE_SOCKET_FAILD, LOCAL_LANG).socket_strerror(socket_last_error()),
                                   Logger::FAILD);
            return false;
        }

        $set_opt_res = socket_set_option($this->_socket, SOL_SOCKET, SO_RCVTIMEO, array('sec'  => $this->_conn_timeout,
                                                                                        'usec' => 0));
        if( false === $set_opt_res ){
            $this->logger->logging(I18n::get(I18n::SET_SOCKET_OPTION_FAILD, LOCAL_LANG).socket_strerror(socket_last_error()),
                                   Logger::FAILD);
            return false;
        }

        $_conn_result = socket_connect($this->_socket, $this->_host, $this->_port);
        if( false === $_conn_result ){
            $this->logger->logging(I18n::get(I18n::CONNECT_FAILD, LOCAL_LANG).socket_strerror(socket_last_error()),
                                   Logger::FAILD);
            return false;
        }
        return true;
    }

    /**
     * 析构方法
     * 不在使用该类对象时，关闭socket流
     */
    public function __destruct(){
        if( $this->_socket ) { socket_close($this->_socket); }
    }
}
