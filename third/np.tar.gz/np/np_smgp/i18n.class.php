<?php
/**
 * 中国电信SMGP协议
 * 系统消息多语言文件
 *
 * @Usege:
 * [Usege]
 *
 * @Author:      tom.chen <ziwei.chen@starcor.cn>
 * @DateTime:    2015-09-30 11:34:06
 */

namespace NpSmgp;

class I18n{
    const CAN_NOT_CONNECT_SMGP      = 400;
    const NOT_INPUT_HOST_OR_PORT    = 401;
    const CLIENT_ID_PASSWD_EMPTY    = 402;
    const MESSAGE_IS_NULL           = 403;
    const MESSAGE_CAN_NOT_BE_EMPTY  = 405;
    const SEVER_NOT_SUPPORT_COVERT  = 406;
    const MESSAGE_CAN_NOT_BE_COVERT = 407;
    const CLIENT_ID_PASSWD_NULL     = 408;
    const CONNET_NEED_LOGGER        = 409;
    const CONNECT_NEED_HOST_PORT    = 410;
    const READ_PACKAGE_IS_ZORE      = 411;
    const READ_MESSAGE              = 412;
    const SEND_MESSAGE              = 413;
    const CREATE_SOCKET_FAILD       = 414;
    const SET_SOCKET_OPTION_FAILD   = 415;
    const CONNECT_FAILD             = 416;
    const LOGIN                     = 417;
    const UNKOWN                    = 404;
    const ERROR                     = 418;
    const SUCCESS                   = 419;
    const WARNNING                  = 420;
    const OK                        = 421;
    const NOTICE                    = 422;
    const FAILD                     = 423;
    const UNSAFE                    = 424;
    const CREDIBLE                  = 425;
    const UNREACHABLE               = 426;
    const LOGOUT                    = 427;
    const UNCREDIBLE                = 428;
    const CANNOT_CLOSE_LOG_FILE     = 429;
    const CANNOT_MAKE_DIR_FOR_LOG   = 430;
    const CANNOT_MAKE_MONTH_DIR     = 431;
    const PACK_HEADER_NOT_ENOUGH    = 432;
    const CONNECT_IS_LOSTED         = 433;
    const READ_SMS_RESULT_FAILD     = 434;
    const READ_LOGIN_RESULT_FAILD   = 435;
    const READ_SMS_HEADER_ERROR     = 436;

    const ZH_CN                     = 'zh_CN';
    const ZH_TW                     = 'zh_TW';
    const ZH_HK                     = 'zh_HK';
    const EN_US                     = 'en_US';
    const EN_UK                     = 'en_UK';


    private static $i18n_en_us = array(400 => "Can not connect to server of smgp.",
                                       401 => "Please input a vaild host[ %s ] and port[ %d ]",
                                       402 => "Client id, password and spid can not be empty.",
                                       403 => "Message is null.",
                                       405 => 'Message which will be send is empty.',
                                       406 => 'Server cannot support this: iconv && mb_convert_encoding, can not continue.',
                                       407 => 'Cannot covert this message\'s encoding.',
                                       408 => "Login infomation: client_id or password is null.",
                                       409 => 'Connect need a logger object instance of NpSmgp\Logger, exited.',
                                       410 => 'Connect must be have host and port with smgp.',
                                       411 => 'Read message: read length of package is zore.',
                                       412 => 'Read message: ',
                                       413 => 'Send message: ',
                                       414 => 'Create socket faild: ',
                                       415 => 'Set socket options faild:',
                                       416 => 'Connect faild: ',
                                       417 => 'Login',
                                       418 => 'Error',
                                       419 => 'Success',
                                       420 => 'Warnning',
                                       421 => 'OK',
                                       422 => 'Notice',
                                       423 => 'Faild',
                                       424 => 'Unsafe',
                                       425 => 'Credible',
                                       426 => 'Unreachable',
                                       427 => 'Logout',
                                       428 => 'Uncredible',
                                       429 => "Can not colse the log file.",
                                       430 => 'Can not make the directory for log file.',
                                       431 => 'Can not make the directory of log file by month.',
                                       432 => 'The lenght of header of package not enough.',
                                       433 => 'The connect of socket is losted.',
                                       434 => 'Read the package of result of sms is faild.',
                                       435 => 'Read the package of result of login is faild.',
                                       436 => 'Read the header of package is not vaild.',
                                       404 => 'Unkown');

    private static $i18n_zh_cn = array(400 => "无法连接SMGP服务器。",
                                       401 => "请输入一个正确的主机地址[ %s ]和端口[ %d ]",
                                       402 => "client id,password和spid不能为空.",
                                       403 => "信息为空.",
                                       405 => '发送的消息内容为空.',
                                       406 => '服务器平台不支持文字转换方法: iconv && mb_convert_encoding, 无法继续发送短信.',
                                       407 => '发送的消息格式无法转换.',
                                       408 => "登陆信息:client_id或password为空.",
                                       409 => '连接类connet需要一个NpSmgp\Logger实例, 退出.',
                                       410 => '连接类connect需要SMGP的主机地址好端口.',
                                       411 => '读取信息: 读取的数据包大小为0.',
                                       412 => '读取信息: ',
                                       413 => '发送信息: ',
                                       414 => '创建socket流失败: ',
                                       415 => '设置socket流选项失败:',
                                       416 => '连接失败: ',
                                       417 => '登陆',
                                       418 => '错误',
                                       419 => '成功',
                                       420 => '警告',
                                       421 => 'OK',
                                       422 => '注意',
                                       423 => '失败',
                                       424 => '不安全的',
                                       425 => '可信的',
                                       426 => '不可达的',
                                       427 => '登出',
                                       428 => '不可信的',
                                       429 => "无法关闭打开日志文件.",
                                       430 => '无法为日志文件创建目录.',
                                       431 => '无法创建月份日志目录.',
                                       432 => '包头长度不够',
                                       433 => 'socket连接丢失或被服务器端积极关闭。',
                                       434 => '读取发送信息返回数据包失败.',
                                       435 => '读取登陆信息返回数据包失败.',
                                       436 => '读取的包不是短信响应包或者流水号不正确',
                                       404 => '未知的');


    public static function get($code, $i18n='en_US'){
        $local_arr = self::get_i18n_arr($i18n);

        if( !array_key_exists($code, $local_arr) ){
            $code = self::UNKOWN;
        }

        return $local_arr[$code];
    }

    private static function get_i18n_arr($i18n){
        switch($i18n){
            case self::ZH_CN:
                return self::$i18n_zh_cn;
            default:
                return self::$i18n_en_us;
        }
    }
}