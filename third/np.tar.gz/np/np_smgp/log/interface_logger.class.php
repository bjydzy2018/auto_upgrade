<?php
/**
 * 中国电信SMGP协议
 * 日志记录类接口
 *
 * @Usege:
 * [Usege]
 *
 * @Author:      tom.chen <ziwei.chen@starcor.cn>
 * @DateTime:    2015-09-24 15:29:26
 */
 namespace NpSmgp\Log;

 interface InterfaceLogger {
    public function __construct($path = null, $mode = null, $name = null, $callback_func = null);
 }