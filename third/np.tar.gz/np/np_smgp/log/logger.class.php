<?php
/**
 * 记录日志类
 *
 * @Usege:
 * require_once("<your path>/np_smgp/log/logger.class.php");
 * use NpSmgp;
 * $logger = new NpSmgp\Log\Logger();
 * $logger->logging("error message.");
 *
 * @Author:      tom.chen <ziwei.chen@starcor.cn>
 * @DateTime:    2015-09-23 16:28:05
 */
namespace NpSmgp\Log;

require_once(dirname(__FILE__).DIRECTORY_SEPARATOR.'interface_logger.class.php');
if( !defined("DEFAULT_LOG_PATH") )
    define("DEFAULT_LOG_PATH", dirname(__FILE__).DIRECTORY_SEPARATOR."log".DIRECTORY_SEPARATOR);

class Logger implements InterfaceLogger {
    protected $_log_path       = '';
    //0 只记录到一个文件
    const LOG_MODE_SINGLE_FILE = 0;
    //1:按天记录，
    const LOG_MODE_DAILY       = 1;
    //2:按月记录,
    const LOG_MODE_MONTH       = 2;
    //3, 记录到数据库 或者 其他介质，使用此项时需制定保存的方法
    const LOG_MODE_OTHER       = 3;
    protected $_log_mode       = self::LOG_MODE_DAILY;
    protected $_log_name       = "smgp_log";
    protected $_log_db_func    = null;
    protected $_log_file_ext   = ".log";

    const ERROR                = 0;
    const SUCCESS              = 1;
    const WARNNING             = 2;
    const OK                   = 3;
    const NOTICE               = 4;
    const FAILD                = 5;
    const UNSAFE               = 6;
    const CREDIBLE             = 7;
    const UNCREDIBLE           = 8;
    const LOGIN                = 9;
    const LOGOUT               = 10;
    const UNREACHABLE          = 11;

    public function __construct($path = null, $mode = null, $name = null, $callback_func = null){
        if( !empty($path) ){
            if( substr($path, -1, 1) !== DIRECTORY_SEPARATOR )
                $path .= DIRECTORY_SEPARATOR;
            $this->_log_path = $path;
        }
        else{
            $this->_log_path = DEFAULT_LOG_PATH;
        }

        // 吐槽：(0..3).to_a是多么好用
        $log_modes = array( self::LOG_MODE_SINGLE_FILE,
                            self::LOG_MODE_DAILY,
                            self::LOG_MODE_MONTH,
                            self::LOG_MODE_OTHER );

        if( !empty($mode) && in_array((int) $mode, $log_modes) ){
            $this->_log_mode = (int) $mode;
        }

        if( !empty($name) ){
            $this->_log_name = $name;
        }

        if( !empty($callback_func) ){
            if( (is_array($callback_func) && is_callable($callback_func)) || function_exists($callback_func) ){
                $this->_log_db_func = $callback_func;
            }
        }

        $this->mkdir();
    }

    /**
     * 记录日志到指定的地方
     * @param  string $msg 日志内容
     * @return boolean
     */
    public function logging($msg){
        switch( $this->_log_mode ){
            case self::LOG_MODE_OTHER:
                return call_user_func_array($this->_log_db_func, $msg);
            case self::LOG_MODE_MONTH:
            case self::LOG_MODE_DAILY:
            case self::LOG_MODE_SINGLE_FILE:
                return $this->log2file($msg);
            default:
                return false;
        }
    }

    /**
     * 将日志保存到日志文件中
     * @param  [type] $msg [description]
     * @return [type]      [description]
     */
    protected function log2file($msg){
        $log_file = $this->get_log_name();
        if( $fhand = fopen($log_file, 'a') ){
            $write_result = @fwrite($fhand, $msg."\r\n");
            if( !@fclose($fhand) ){
                throw new \Exception(\NpSmgp\I18n::get(\NpSmgp\I18n::CANNOT_CLOSE_LOG_FILE, \NpSmgp\LOCAL_LANG));
            }
            return $write_result;
        }
        return false;
    }

    /**
     *  根据模式创建目录
     * @return void
     */
    protected function mkdir(){
        if( self::LOG_MODE_OTHER > $this->_log_mode ){
            if( !is_dir($this->_log_path) && !$this->mkpdir($this->_log_path, 0755) ){
                throw new \Exception(\NpSmgp\I18n::get(\NpSmgp\I18n::CANNOT_MAKE_DIR_FOR_LOG, \NpSmgp\LOCAL_LANG));
                return false;
            }

            // 如果是按天保存日志数据的，那么我们将为其按月保存
            if( self::LOG_MODE_DAILY == $this->_log_mode && 
                !is_dir(($this->_log_path .= date("Y-m", time()))) ){
                if( !@\mkdir($this->_log_path, 0755) ){
                    throw new \Exception(\NpSmgp\I18n::get(\NpSmgp\I18n::CANNOT_MAKE_MONTH_DIR, \NpSmgp\LOCAL_LANG));
                    return false;
                }
            }
        }
        return true;
    }

    /**
     * 获取文件名称
     * @return string
     */
    protected function get_log_name(){
        if( self::LOG_MODE_OTHER > $this->_log_mode ){
            switch($this->_log_mode){
                case self::LOG_MODE_DAILY:
                   $log_part = "_".date("Y-m-d", time());
                   break;
                case self::LOG_MODE_MONTH:
                    $log_part = "_".date("Y-m", time());
                    break;
                default:
                    $log_part = "";
            }

            return sprintf("%s".DIRECTORY_SEPARATOR."%s%s.log", $this->_log_path, $this->_log_name, $log_part);
        }

        return null;
    }

    /**
     * 创建文件夹包括其父文件夹
     * @param  string  $dir  文件夹路径
     * @param  integer $mode 文件夹权限
     * @return boolean 创建状态
     */
    protected function mkpdir($dir, $mode=0700){
        $dir     = preg_replace("/[\\".DIRECTORY_SEPARATOR."]{2,}/", DIRECTORY_SEPARATOR, $dir);
        $dir_arr = explode(DIRECTORY_SEPARATOR, $dir);
        if( 0 < ($dir_arr_count = count($dir_arr)) ){
            #TODO windows上开始不知道怎么处理好。所以windows必须传入一个完整的路径
            $path = ( "/" == DIRECTORY_SEPARATOR ) ?
                    (( "/" != $dir[0] ) ? dirname(__FILE__).DIRECTORY_SEPARATOR : "" ) :
                    "";
            $path .= $dir;
            if( DIRECTORY_SEPARATOR != substr($path, -1, 1) )
                $path .= DIRECTORY_SEPARATOR;

            $unmaked_dir_arr = array();
            do{
                $dir_arr_count--;
                $d_name = $dir_arr[$dir_arr_count];
                if( !is_dir($path) ){
                    // 尝试创建目录，如果创建失败，则将无法创建的目录存入到需创建的数组，然后再将此目录名称从目录路径中移除。
                    if( !@\mkdir($path, $mode) ){
                        array_push($unmaked_dir_arr, $d_name);
                        $path = substr($path, 0, (strlen($path) - strlen($d_name) -1));
                    }
                }
                else{ break; }
            }while( 0 < $dir_arr_count );

            // 按数组倒序创建目录
            // 如果创建某层目录失败，则返回false
            if( ($unmake_count = count($unmaked_dir_arr)) > 0 ){
                while($unmake_count > 0){
                    $unmake_count--;
                    $path .= $unmaked_dir_arr[$unmake_count].DIRECTORY_SEPARATOR;
                    if( !\mkdir($path, $mode) )
                        return false;
                }
            }
        }

        return true;
    }

    protected static function get_level_str($level){
        switch((int) $level){
            case self::ERROR:
                return 'Error';
            case self::SUCCESS:
                return 'Success';
            case self::WARNNING:
                return 'Warnning';
            case self::OK:
                return 'OK';
            case self::NOTICE:
                return 'Notice';
            case self::FAILD:
                return 'Faild';
            case self::UNSAFE:
                return 'Unsafe';
            case self::CREDIBLE:
                return 'Credible';
            case self::UNREACHABLE:
                return 'Unreachable';
            case self::LOGIN:
                return 'Login';
            case self::LOGOUT:
                return 'Logout';
            case self::UNCREDIBLE:
                return 'Uncredible';
            default:
                return 'Unkown';
        }
    }
}