<?php
/**
 * 记录日志类
 *
 * @Usege:
 * require_once("<your path>/np_smgp/logger.class.php");
 * use NpSmgp;
 * $logger = new NpSmgp\Logger();
 * $logger->logging("error message.");
 *
 * @Author:      tom.chen <ziwei.chen@starcor.cn>
 * @DateTime:    2015-09-23 16:28:05
 */
namespace NpSmgp;

require_once(dirname(__FILE__).DIRECTORY_SEPARATOR.'log'.DIRECTORY_SEPARATOR.'logger.class.php');

class Logger extends Log\Logger {
    public function __construct($path = null, $mode = null, $name = null, $callback_func = null){
        parent::__construct($path, $mode, $name, $callback_func);
    }

    /**
     * 记录日志到指定的地方
     * @param  string $msg 日志内容
     * @return boolean
     */
    public function logging($format, $error_level=OK){
        $params = array("%s  [SMGP]  [%-11s] ".$format, date("Y-m-d H:i:s", time()), self::get_level_str($error_level));
        if( func_num_args() > 2 ){
            array_splice(($user_params = func_get_args()), 0, 3, $params);
            $params = $user_params;
            //$params = array_merge($params, array_splice(func_get_args(), 2));
        }
        $msg = call_user_func_array("sprintf", $params);

        parent::logging($msg);

        if( $error_level == self::ERROR ){ die; }
    }
}