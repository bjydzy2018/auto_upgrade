<?php
/**
 * 中国电信SMGP协议
 * 短信内容格式化以及分条类
 *
 * @Usege:
 * require_once("<your path>/np_smgp/message.class.php");
 * use NpSmgp;
 * $msg = new Message($msg, 200, 1, $logger);
 * while( ($single_msg = $msg->get_formated_contents()) ){
 *     // your code..
 * }
 *
 * @Author:      tom.chen <ziwei.chen@starcor.cn>
 * @DateTime:    2015-09-29 10:36:12
 */

namespace NpSmgp;
if( !defined('CLASS_ROOT_PATH'))
    define("CLASS_ROOT_PATH", dirname(__FILE__).DIRECTORY_SEPARATOR);

require_once(CLASS_ROOT_PATH.'code'.DIRECTORY_SEPARATOR."include_code.php");
require_once(CLASS_ROOT_PATH.'logger.class.php');

class Message{
    private $_unformated_msg     = '';
    private $_encoding_name      = 'UTF-8';
    private $_from_encoding_name = 'UTF-8';
    private $_single_limit       = 140;
    private $_logger             = null;
    private $_formated_msg       = array();
    private $_total_msg_pages    = 1;
    private $_got_msg_num        = 1;
    private $_current_msg        = '';

    public function __construct($msg, $single_msg=140, $format_type=15, Logger $logger=null, $from_ending_name=null){
        if( !empty($logger) ){
            $this->_logger = $logger;
        }
        else{
            $this->_logger = new Logger();
        }

        if( !empty($msg) ){
            $this->_unformated_msg = $msg;
        }
        else{
            $this->_logger->logging(I18n::get(I18n::MESSAGE_CAN_NOT_BE_EMPTY, LOCAL_LANG), Log\Logger::ERROR);
            throw new \Exception(I18n::get(I18n::MESSAGE_CAN_NOT_BE_EMPTY, LOCAL_LANG));
            die;
        }

        if( (int)$single_msg > 0 ){
            $this->_single_limit = $single_msg;
        }

        if( !empty($from_ending_name) )
            $this->_from_encoding_name = $from_ending_name;

        $this->_encoding_name = Code\MsgFormat::get_format_encoding( (int)$format_type );

        if( $this->_from_encoding_name != $this->_encoding_name )
            $this->formatting();
    }

    public function get_single_message(){
        return array($this->_current_msg=array_shift($this->_formated_msg), $this->_got_msg_num++,
                     $this->_total_msg_pages);
    }

    public function rollback(){
        array_unshift($this->_formated_msg, $this->_current_msg);
        $this->_got_msg_num--;
    }

    /**
     * 格式化消息内容
     * @return void
     */
    private function formatting(){
        // 将消息内容转换为指定的编码格式
        $this->coverting();

        if( $this->_single_limit >= ($msg_total = strlen($this->_unformated_msg)) ){
            $this->_formated_msg[0] = $this->_unformated_msg;
        }
        else{
            $this->_total_msg_pages = (int) ceil($msg_total / ($pre_page_num = $this->_single_limit - 6));
            $this->_formated_msg    = array_fill(0, $this->_total_msg_pages, null);

            for( $p = 0; $p < $this->_total_msg_pages; $p++ ){
                $this->_formated_msg[$p] = substr($this->_unformated_msg, ($p * $pre_page_num), $pre_page_num);
            }
        }
    }

    /**
     * 转换消息内容编码格式
     * @return string/binary
     */
    private function coverting(){
        if( "BINARY" == $this->_encoding_name )
            $this->_unformated_msg = self::covert_str_to_binary($this->_unformated_msg);
        else{
            $format_result = self::covert_to_encoding($this->_unformated_msg, $this->_encoding_name, $this->_from_encoding_name);
            if( !$format_result ){
                $this->_logger->logging(I18n::get(I18n::SEVER_NOT_SUPPORT_COVERT, LOCAL_LANG),
                           Log\Logger::ERROR);
                throw new \Exception(I18n::get(I18n::MESSAGE_CAN_NOT_BE_COVERT, LOCAL_LANG));
                die;
            }
            else{ $this->_unformated_msg = $format_result; }
        }
    }

    /**
     * 转换消息内容为二进制内容
     * @param  string $str 消息内容
     * @return binary
     */
    private static function covert_str_to_binary($str){
        return pack("a*", $str);
    }

    /**
     * 转换消息编码
     * @param  string $str         消息内容
     * @param  string $to_encoding 最终编码类型
     * @return string
     */
    private static function covert_to_encoding($str, $to_encoding, $from_encoding='UTF-8'){
        if( self::is_support_func_iconv() ){
            return iconv($from_encoding, $to_encoding, $str);
        }
        // elseif( self::is_support_func_mb() )
        //     return mb_convert_encoding($str, $to_encoding);

        return false;
    }


    /**
     * 确定是否支持iconv方法
     * @return boolean
     */
    private static function is_support_func_iconv(){
        return (function_exists('iconv') && function_exists('iconv_get_encoding'));
    }

    /**
     * 确定是否支持mb_convert_encoding方法
     * @return boolean
     */
    private static function is_support_func_mb(){
        return (function_exists('mb_convert_encoding'));
    }
}