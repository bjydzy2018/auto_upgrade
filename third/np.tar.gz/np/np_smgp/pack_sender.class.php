<?php
/**
 * 打包发送数据类
 *
 * @Usege:
 * [Usege]
 *
 * @Author:      tom.chen <ziwei.chen@starcor.cn>
 * @DateTime:    2015-09-24 14:13:48
 */
namespace NpSmgp;

class PackSender{
    const SEQUENCE_ID_MAX         = 0xFFFFFFFF;
    const SEQUENCE_ID_MIN         = 0x00000000;
    const LOGIN_BODY_LEN          = 30;

    private $conn                 = null;
    private $logger               = null;
    private $client_version       = 0;
    private $client_id            = null;
    private $client_passwd        = null;
    private $phone_limit_pre_time = 100;

    /**
     * 初始化数据：
     * @param Connect $conn 连接SMGP协议网关对象
     * @param int $client_ver 客户端版本
     * @param int $client_id 客户端ID
     * @param string $client_pwd 客户端验证key
     * @param Logger $logger 日志记录对象
     */
    public function __construct(Connect $conn, $client_ver, Logger &$logger){
        //初始化一些必要的数据
        $this->conn           = $conn;
        $this->client_version = $client_ver;
        $this->logger         = $logger;
    }

    /**
     * 生成登录所需的包
     * @return bin data
     */
    public function login($client_id, $client_pwd, $login_mode=Code\LoginMode::LOGIN){
        $this->client_id     = $client_id;
        $this->client_passwd = $client_pwd;

        $pack_header         = $this->generate_msg_header( self::LOGIN_BODY_LEN, Code\RequestId::LOGIN,
                                                           $seq_id=self::get_sequence_id() );
        $pack_body           = pack("a8",  $this->client_id);
        $pack_body          .= pack("a16", $this->generate_login_auth_key());
        $pack_body          .= pack("h",   $login_mode);
        $pack_body          .= pack("N",   date("mdHis"));
        $pack_body          .= pack("h",   $this->client_version);
        // var_dump(unpack("N3t1/a8t2/a16t3/ht4/Nt5/ht6", $pack_header.$pack_body));

        $responses   = new Result( $this->conn->send($pack_header.$pack_body), $seq_id, $this->logger );
        if( $responses instanceof Result ){
            return $responses->get_login_result();
        }
        return false;
    }

    /**
     * 生成登出所需的包
     * @return bin data
     */
    public function logout(){
        $msg_header = $this->generate_msg_header(0, Code\RequestId::EXIT_RQ, $seq_id=self::get_sequence_id());
        $responses  = new Result( $this->conn->send($msg_header), $seq_id, $this->logger );

        if( $responses instanceof Result ){
            $this->conn = null;
            return $responses->get_logout_result();
        }
        return false;
    }

    /**
     * 生成发送单条消息的数据包
     * @param  string $msg     短信内容
     * @param  array  $options 一些额外的可选参数
     * @param  string $phone   接收放方数据
     * @return bin data
     */
    public function send_single_sms($msg, $options=array(), $phone){
        $phone                         = (float) $phone;
        if( $phone < 0 ) { return false; }

        $options['msg_length']         = strlen($msg);
        $options['msg_content']        = $msg;
        $options['dest_term_id_count'] = 1;
        $options['dest_term_id']       = array($phone);
        return $this->send_sms($options);
    }

    /**
     * 生成发送多条消息的数据包(数组)
     * @param  string $msg     短信内容
     * @param  array  $options 可选参数
     * @param  array $phones  接收方号码数组
     * @return bin data
     */
    public function send_multi_sms_by_array($msg, $options=array(), $phones){
        $phones = array_unique($phones);
        $phone_count = count($phones);
        if( $phone_count == 0 ){ return false; }

        $options['msg_length']         = strlen($msg);
        $options['msg_content']        = $msg;
        //var_dump($options);
        if( $phone_count > $this->phone_limit_pre_time ){
            $group_phones = array_chunk($phones, $this->phone_limit_pre_time, false);
            $result       = array();
            foreach ($group_phones as $pre_phones) {
                $options['dest_term_id_count'] = count($pre_phones);
                $options['dest_term_id']       = $pre_phones;
                array_push($result, $this->send_sms($options));
            }
            return $result;
        }
        else{
            $options['dest_term_id_count'] = $phone_count;
            $options['dest_term_id']       = $phones;
            return $this->send_sms($options);
        }
    }

    /**
     * 生成多条消息的数据包(变参)
     * @param  string $msg     消息内容
     * @param  array  $options 可选参数
     * @params 可变参数
     * @return bin data
     */
    public function send_multi_sms($msg, $options=array()){
        if( ($phone_number = func_num_args() - 2) > 0 ){
            if( 1 == $phone_number ){
                return $this->send_single_sms($msg, $options, func_get_args()[2]);
            }
            else{
                return $this->send_multi_sms_by_array($msg, $options, array_slice(func_get_args(), 2, $phone_number));
            }
        }

        return false;
    }

    private function send_sms($options){
        $msg_body   = $this->generate_sms_body($options);
        $seq_id     = self::get_sequence_id(isset($options['tp_udhi']) ? $options['tp_udhi'] : null);
        $msg_header = $this->generate_msg_header( strlen($msg_body), Code\RequestId::SUBMIT, $seq_id );
        $responses  = new Result( $this->conn->send($msg_header.$msg_body), $seq_id, $this->logger );

        if( $responses instanceof Result ){
            $result = $responses->get_send_sms_result();
            return $result;
        }
        return false;
    }

    /**
     * 打包生成消息头
     * @param integer $pack_len 消息体长度
     * @param hex $request_id 消息类型
     * @return bin $pack
     */
    private function generate_msg_header($pack_len, $request_id, $seq_id){
        if( $pack_len < 1){
            $this->logger->logging(I18n::get(I18n::MESSAGE_IS_NULL, LOCAL_LANG), Log\Logger::WARNNING);
        }
        $pack_len += 12;

        return pack("NNN", $pack_len, $request_id, $seq_id);
    }

    /**
     * 获取消息流水号
     * @return int
     */
    private static function get_sequence_id($tp_udhi=null){
        global $global_sequence_id;
        if( isset($tp_udhi) && (list($tag, $pk_total, $pk_number) = $tp_udhi)
            && $tag == 1 && $pk_number > 1 && $pk_total > 1 )
            return $global_sequence_id;

        return ( $global_sequence_id > self::SEQUENCE_ID_MAX ) ?
               ($global_sequence_id = self::SEQUENCE_ID_MIN ) :
               ((int)$global_sequence_id += 1);
    }

    /**
     * 生成登录所需的验证AuthenticatorClient
     * @return bin
     */
    private function generate_login_auth_key(){
        if( empty($this->client_id) || empty($this->client_passwd) )
            $this->logger->logging(I18n::get(I18n::CLIENT_ID_PASSWD_NULL, LOCAL_LANG), Log\Logger::WARNNING);
        $auth_key = $this->client_id.str_repeat("\0", 7).$this->client_passwd.date("mdHis");
        $auth_key =  md5( $auth_key, 16 );
        return $auth_key;
    }

    /**
     * 检查并分组电话号码
     * @param  array $phones 电话号码数组
     * @return array
     */
    private function check_and_rebuild_phones($phones){
        $phones = array_unique($phones);

        $group_phones     = array();
        $pre_group_phones = array();
        $pre_phone_number = 0;
        $group_number     = 0;
        foreach ($phones as $phone) {
            if( ($phone = (int) $phone) > 0 ){
                $pre_group_phones[$pre_phone_number] = $phone;
                $pre_phone_number++;
            }

            if( $pre_phone_number >= $this->phone_limit_pre_time ){
                $group_phones[$group_phones] = $pre_group_phones;
                $pre_group_phones            = array();
                $group_number++;
                $pre_phone_number            = 0;
            }
        }

        return $group_phones;
    }

    /**
     * 生成发送消息所需的信息二进制数据
     * @param  array $opt body选项
     * @return binary
     */
    private function generate_sms_body($opts){
        $sms_body  = pack("h",          $opts['msg_type']);
        $sms_body .= pack("h",          $opts['need_report']);
        $sms_body .= pack("h",          $opts['priority']);
        $sms_body .= pack("a10",        $opts['service_id']);
        $sms_body .= pack("a2",         $opts['fee_type']);
        $sms_body .= pack("a6",         $opts['fee_code']);
        $sms_body .= pack("a6",         $opts['fixed_fee']);
        $sms_body .= pack("h",          $opts['msg_format']);
        $sms_body .= pack("a17",        $opts['vaild_time']);
        $sms_body .= pack("a17",        $opts['at_time']);
        $sms_body .= pack("a21",        $opts['src_term_id']);
        $sms_body .= pack("a21",        $opts['charge_term_id']);
        $sms_body .= pack("h",          $opts['dest_term_id_count']);

        foreach( $opts['dest_term_id'] as $dest_term_id ){
            $sms_body .= pack("a21",    $dest_term_id);
        }


        $this->generate_sms_content_pack($opts, $sms_body);

        //var_dump(unpack("ha1/ha2/ha3/a10b/a2c/a6d/a6e/hf/a17g/a17h/a21i/a21j/hk/a21l/Sm/H140n/a8o/Hp/Hq/hr", $sms_body));
        //die;
        return $sms_body;
    }

    private function generate_sms_content_pack($opt, &$body){
        // 設置可選參數数据
        if( isset($opt['tp_udhi']) && is_array($opt['tp_udhi']) &&
            (list($udhi, $pk_total, $pk_number) = $opt['tp_udhi']) ){
            $msg_length          = $opt['msg_length'] + 6;
            $body               .= pack("H*",         dechex($msg_length));
            // 打包长短信消息头
            $spliter_sms_header  = pack("hhhhhh",     0x05, 0x00, 0x03, 0x00,
                                                      dechex($pk_total), dechex($pk_number));
            $body               .= $spliter_sms_header;
            //$body .= pack("h*",         dechex($opt['msg_length']));
            $body               .= $opt['msg_content'];
            $body               .= pack("a8",         null);
            $spid_len            = strlen($opt['src_term_id']);

            // 设置一些其他可选的信息
            // 废弃，会导致发送的数据偶发错误，并且没什么卵用
            /*$body               .= pack("hH2h",     0x00, dechex(Code\OptionParams::MSG_SRC), 0x00);
            $body               .= pack("h*",         dechex($spid_len));

            $body               .= pack("a{$spid_len}", $opt['src_term_id']);

            if( !empty($opt['product_id'])){
                $pid_len        = strlen($opt['product_id']);
                $body          .= pack("hH2h",        0x00, dechex(Code\OptionParams::MSERVICE_ID), 0x00);
                $body          .= pack("H*",          dechex($pid_len));
                $body          .= pack("a{$pid_len}", $opt['product_id']);
            }*/
            // 设置超长短信标示
            $body               .= pack("hhhhh",      0x00, dechex(Code\OptionParams::TP_UDHI), 0x00, 0x01, 0x01);
            // 设置超长短信当前条数
            $body               .= pack("hhhhh",      0x00, dechex(Code\OptionParams::PK_NUMBER), 0x00, 0x01,
                                                      dechex($pk_number));
            // 设置超长短信总条数
            $body               .= pack("hhhhh",      0x00, dechex(Code\OptionParams::PK_TOTAL), 0x00, 0x01,
                                                      dechex($pk_total));
        }
        else{
            $body               .= pack("H*",         dechex($opt['msg_length']));
            $body               .= $opt['msg_content'];
            $body               .= pack("a8",         null);
        }
    }
}
