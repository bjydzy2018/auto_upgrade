<?php
/**
 * 中国电信SMGP协议
 * 解包返回信息数据
 *
 * @Usege:
 * require_once("<your path>/np_smgp/result.class.php");
 * $result = new NpSmgp\Result($conn, $logger);
 * $result->get_login_msg();
 *
 * @Author:      tom.chen <ziwei.chen@starcor.cn>
 * @DateTime:    2015-09-24 14:03:46
 */

namespace NpSmgp;

class Result{
    private $_conn        = null;
    private $logger       = null;
    private $_seq_id      = 0;

    const LOGIN_PACK_LEN  = 33;
    const SMS_PACK_LEN    = 26;
    const HEADER_PACK_LEN = 12;

    public function __construct(Connect $conn, $seq_id, Logger &$logger){
        if( $conn ){ $this->_conn = $conn; }

        if( !empty($seq_id) ){ $this->_seq_id = $seq_id; }

        if( $logger ){ $this->logger = $logger; }
    }


    /**
     * 获取登陆后服务器返回的消息数据
     * @return boolean/array
     */
    public function get_login_result(){
        if( empty($this->_conn) ){
            $this->logger->logging(I18n::get(I18n::CONNECT_IS_LOSTED, LOCAL_LANG), Log\Logger::FAILD);
            return false;
        }

        // 其中12字节是包头。
        $response = $this->_conn->read(self::LOGIN_PACK_LEN);
        if( $response ){
            extract(self::unpack_header($response));
            // 如果读取的包不是登陆包或者流水号不正确则返回false
            if( $req_id !== (int)Code\RequestId::LOGIN_RESP || $this->_seq_id != $seq_id ){
                $this->logger->logging(I18n::get(I18n::READ_LOGIN_RESULT_FAILD, LOCAL_LANG),
                                       Log\Logger::FAILD);
                return false;
            }

            extract(unpack("Nstatus/a16auth/hver", $response));

            $socket_last_msg = Code\Status::get_status_msg($status);
            if( $status == Code\Status::SUCCESS ){
                $logger_status = Log\Logger::SUCCESS;
                $socket_result = array(true, $auth, $ver, $socket_last_msg);
            }
            else{
                $socket_result = array(false, null, null, $socket_last_msg);
                $logger_status = Log\Logger::FAILD;
            }
            $this->logger->logging(I18n::get(I18n::LOGIN, LOCAL_LANG).$socket_last_msg, $logger_status);
            return $socket_result;
        }
        else{
            $this->logger->logging(I18n::get(I18n::READ_LOGIN_RESULT_FAILD, LOCAL_LANG).$socket_last_msg,
                                   Log\Logger::FAILD);
        }

        return false;
    }

    /**
     * 获取发送消息的应答
     * @return  boolean/array
     */
    public function get_send_sms_result(){
        if( empty($this->_conn) ){
            $this->logger->logging(I18n::get(I18n::CONNECT_IS_LOSTED, LOCAL_LANG), Log\Logger::FAILD);
            return false;
        }

        // 其中12字节是包头。
        $response = $this->_conn->read(self::SMS_PACK_LEN);
        if( $response ){
            extract(self::unpack_header($response));
            // 如果读取的包不是短信响应包或者流水号不正确则返回false
            // var_dump($req_id, Code\RequestId::SUBMIT_RESP, $seq_id, $this->_seq_id);
            if( $req_id !== (int)Code\RequestId::SUBMIT_RESP || $this->_seq_id != $seq_id ){
                $this->logger->logging(I18n::get(I18n::READ_SMS_HEADER_ERROR, LOCAL_LANG),
                                       Log\Logger::FAILD);
                return false;
            }

            extract(unpack("a10msg_id/Nstatus", $response));
            $socket_last_msg = Code\Status::get_status_msg($status);

            if( $status == Code\Status::SUCCESS ){
                $logger_status = Log\Logger::SUCCESS;
                $socket_result = array(true, $msg_id, $socket_last_msg);
            }
            else{
                $logger_status = Log\Logger::FAILD;
                $socket_result = array(false, null, $socket_last_msg);
            }
            $this->logger->logging(I18n::get(I18n::SEND_MESSAGE, LOCAL_LANG).$socket_last_msg, $logger_status);
            return $socket_result;
        }
        else{
            $this->logger->logging(I18n::get(I18n::READ_SMS_RESULT_FAILD, LOCAL_LANG),
                                   Log\Logger::FAILD);
        }
        return false;
    }

    /**
     * 获取登出的应答
     * @return  boolean/array
     */
    public function get_logout_result(){
        if( empty($this->_conn) ){ return false; }

        $response = $this->_conn->read(self::HEADER_PACK_LEN);
        if( $response ){
            extract(self::unpack_header($response));
            // 如果读取的包是退出响应包并且流水号正确则返回true
            if( $req_id == Code\RequestId::EXIT_RESP && $this->_seq_id == $seq_id ){ return true; }
        }

        return false;
    }

    /**
     * 解开包头(12字节)
     * @param  binary &$response 包数据，引用关系
     * @return array
     */
    private static function unpack_header(&$response){
        $res_len = strlen($response);
        //　如果包数据长度小于１２字节，则说明此包不是正确的包，则弹出错误消息。
        if( $res_len < self::HEADER_PACK_LEN ){
            throw new \Exception(I18n::get(I18n::PACK_HEADER_NOT_ENOUGH, LOCAL_LANG));
            die;
        }

        $header = substr($response, 0, self::HEADER_PACK_LEN);
        if( $res_len > self::HEADER_PACK_LEN ){ $response = substr($response, self::HEADER_PACK_LEN); }

        return unpack("Npack_len/Nreq_id/Nseq_id", $header);
    }
}
