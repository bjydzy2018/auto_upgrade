<?php
if( !defined("APP_ROOT") )
    define("APP_ROOT", dirname(__FILE__).DIRECTORY_SEPARATOR);
require_once(APP_ROOT."np_smgp.class.php");

$log_path   = APP_ROOT."smgp_logs";
if( !is_dir($log_path) )
    mkdir($log_path);

$phones = array();
$validate_code = '';
$validate_code_length = 10;
for($i=0;;){
    if($i >= $validate_code_length){ break; }
    $validate_code .= chr(rand(48, 90));
    $i++;
}
$smgp               = new NpSmgp();
$smgp->set_log_path($log_path);
$smgp->send_mode    = NpSmgp::FAILD_BREAK;
// $smgp->vaild_time   = date("YmdHis", time()+180);
$result             = $smgp -> send_msg("【新疆广电网络】您当前的验证码是:{$validate_code},该验证码将在２分钟后失效。", $phones);
var_dump($result);
?>
