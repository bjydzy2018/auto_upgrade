<?php
include '../np_mongodb.class.php';
   $config = array(
      'host'   => '127.0.0.1',
      'port'   => '27017',
      'db_name'=> 'nn_stat_test',
      //'user'   => 'root',
      //'passwd' => 'root',
  
   );
   $mongodb = new np_mongodb_class($config);
   $mongodb->open();
   $mongodb->select_collection('test');
   $mongodb->insert(array('title' => '1000', 'username' => 'xcxx') );
