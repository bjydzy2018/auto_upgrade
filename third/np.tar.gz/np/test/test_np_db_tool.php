<?php
/*
 * Created on 2014-3-14
 *
 * 
 * 
 */
require_once('../np_db_factory.php');
require_once('../np_db_tool.class.php');

$config = np_db_build_config( 'localhost', 'root', 'root', 'nn_cms', NP_DB_TYPE_MYSQL ,NP_DB_LOG_NULL);
$db = np_db_factory_create( $config );
$db->open();

$result = np_db_tool_class::get_table_info($db,'nn_core');
/*
$db->query('use information_schema;');
$sql = "select table_name,table_rows from tables where TABLE_SCHEMA = 'nn_cms' order by table_rows desc";
//$sql = "select * from nns_vod limit 1";
$db->query($sql);	
//$result =np_db_tool_class::get_table_info($db,'nn_cms');
$result = $db->get_query_result( TRUE );

*/
echo '<pre>';

var_dump($result);
echo '</pre>';