<?php
/*
 *
 * Created on 2012-8-18
 *
 * @author xsong
 *
 */

require_once('../np_ini_parser.class.php');
$ini_parser =  new np_ini_parser_class();
$ini_parser->load_file('nn_config.ini');
$all_arr = $ini_parser->get_all_section();
var_dump($all_arr);
$section = $ini_parser->get_section('section_2');
var_dump($section);
$ini_content= $ini_parser->save_ini('xx1_config.ini');
echo $ini_content;
