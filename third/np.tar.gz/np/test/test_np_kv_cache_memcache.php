<?php
/*
 * Created on 2012-10-11
 * CZY
 * To change the template for this generated file go to
 * Window - Preferences - PHPeclipse - PHP - Code Templates
 */

include_once dirname( dirname(__FILE__) ).DIRECTORY_SEPARATOR ."np_kv_cache_factory.php" ;

$config = np_kv_cache_build_config( NP_KV_CACHE_TYPE_MEMCACHE, NP_KV_CACHE_MAP_ALL, array("127.0.0.1:11211") );
var_dump($config );
$cache = np_kv_cache_factory_create( $config );
var_dump( $cache );

$cache->open();
var_dump( "cacahe->open ".$cache->last_error_desc() );

if( !$cache->set( "abc", "def", 100 ) )
{
	var_dump( "cache->set false".$cache->last_error_desc() );
}
$val = $cache->get( "abc" );
if( $val == FALSE )
	var_dump(  "cache->get ".$cache->last_error_desc() );

var_dump( $val );

if( !$cache->delete( "abc" ) )
{
	var_dump( "cache->delete false".$cache->last_error_desc() );
}

$val = $cache->get( "abc" );
if( $val == FALSE )
	var_dump(  "cache->get ".$cache->last_error_desc() );

var_dump( $val );

if( !$cache->add( "abc", "def", 100 ) )
{
	var_dump( "cache->set false".$cache->last_error_desc() );
}
$val = $cache->get( "abc" );
if( $val == FALSE )
	var_dump(  "cache->get ".$cache->last_error_desc() );

var_dump( $val );
?>
