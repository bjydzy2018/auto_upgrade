<?php
/*
 *
 * Created on 2012-9-17
 *
 * @author xsong
 *
 */
require_once('../np_log.class.php');
$log = new np_log();
$log_path = dirname(__FILE__).DIRECTORY_SEPARATOR.'data'.DIRECTORY_SEPARATOR.'log';
$log->set_path($log_path);
$log->write('log test');
