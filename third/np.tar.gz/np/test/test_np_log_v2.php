<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

include dirname(dirname(__FILE__)).'/np_log_v2.class.php';
function test_np_log_v2() {
    date_default_timezone_set('PRC');
    $obj_test = new np_log_v2();
    $obj_test->set_dir(dirname(__FILE__) . '/data'); //设置存放路径
    $obj_test->set_level_config('error', 10, 10, 'error', 60);
    $obj_test->set_level_config('info', 10, 10, 'info', 60);
    for ($i = 0; $i < 100; $i++) {
        $obj_test->error('error2error2error2error2error2error2error2error2');
        $obj_test->info('info2info2info2info2info2info2info2info2info2info2');
    }
    $obj_test->save();
}

test_np_log_v2();
