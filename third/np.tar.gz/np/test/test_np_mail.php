<?php
/*
 * Created on 2013-5-23
 * 邮件发送测试
 */
 require_once('../np_mail.class.php');
  $mail_config = array(
     'smtp_server'=>'smtp.126.com',//SMTP服务器
     'smtp_port' =>25,
     'from'=>'xsdys@126.com',
     //以下参数为可选
      'smtp_auth' =>true,
     //如果smtp_auth设置为true，需要验证邮箱
     'smtp_user' =>'xxx',
     'smtp_pass' =>'xxx',
     //'mail_format' => 'HTML/TXT',
     
  );
  $mail = new np_mail_class($mail_config);
  $mail->debug = true;
  $ret = $mail->send('335643942@qq.com','测试邮件主题-'.date('Y-m-d H:i:s'),'测试邮件内容'); 
  if($ret==true){
  	echo 'send ok';
  }else{
  	echo 'send fail';
  }
?>
