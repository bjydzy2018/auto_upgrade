<?php
include '../np_redis.class.php';
include '../np_string.php';
//include '../np_time.php';
ini_set("display_errors",1);
error_reporting(E_ALL);
set_time_limit(0);
  $config = array(
  'host'=>'127.0.0.1',
  'port'=>6379
  );
  $redis = new np_redis_class($config);
  $redis->open();
if ($_GET["delete"]==1)
{
    $redis->get_redis()->flushAll();
    die;
}
//$redis->get_redis()->flushAll();
//  $redis->set('test-set1','hhhhh');
//var_dump($redis->get_slow_log());

//  echo $redis->get('test-set1');
////$redis->hash_table("test")->hash_create_index(array("name","score","age"));
//$redis->hash_table("test")->hash_update("test.123",array("name"=>"test1","score"=>20,"age"=>30));
//$redis->hash_table("test")->hash_update("test.345",array("name"=>"test2","score"=>30,"age"=>30));
//$redis->hash_table("test")->hash_update("test.abc",array("name"=>"test3","score"=>25,"age"=>30));
//$redis->hash_table("test")->hash_update("tttt.123",array("name"=>"test4","score"=>10,"age"=>20));

//$re = $redis->hash_table_query("test",0,100,"*","score","desc","test.[13]*");
//
if ($_GET["create"]==1){
    np_runtime(FALSE);
    $redis->hash_create_table("test",array("name","score","age"),array("name","score","age"),array("age"));
    for ($i=0 ; $i<10; $i++){
        if ($i%1000==0)
        {
            $time = np_runtime(true);
            echo $time."s~".floor($i/1000)."\n";
            np_runtime(FALSE);
        }
//    $id = "test.".np_guid_rand();
        $score = rand(0,1000);
//    $redis->get_redis()->set($id,$score);
        $id = "test._".$i;
        $age = rand(0,30);
        $name = $id;
        $re = $redis->hash_table("test")->hash_update($id,array("name"=>$name,"score"=>$score,"age"=>$age));
    }
    $time = np_runtime(true);
    echo $time."s~".floor($i/1000)."\n";
    die;
}

if ($_GET["mysql"] ==1)
{
    include_once "../np_db_mysql.class.php";
    include_once "../np_sql_builder.class.php";
    $config = array(
        "host"=>"127.0.0.1",
        "user"=>"root",
        "passwd"=>"root",
        "db_name"=>"test",
        "db_log"=>NP_DB_LOG_NULL
    );
    $db = new np_db_mysql_class($config);
    $db->open();
    $sql_b = new np_sql_builder("test");
    np_runtime(FALSE);

    for ($i=0 ; $i<10000; $i++){
        if ($i%1000==0)
        {
            $time = np_runtime(true);
            echo $time."s~".floor($i/1000)."\n";
            np_runtime(FALSE);
        }
        $id = "test._".$i;
        $params = array(
            "name"=>$id,
            "id"=>$id,
            "score"=>rand(0,1000),
            "age"=>rand(0,30),

        );

        $sql = $sql_b->insert($params);

        $db->execute($sql);
//        $re = $redis->hash_table("test")->hash_update($id,array("name"=>$name,"score"=>$score,"age"=>$age));
    }
    $time = np_runtime(true);
    echo $time."s~".floor($i/1000)."\n";
    die;
}

if ($_GET["mysql"] ==2)
{
    include_once "../np_db_mysql.class.php";
    include_once "../np_sql_builder.class.php";
    $config = array(
        "host"=>"127.0.0.1",
        "user"=>"root",
        "passwd"=>"root",
        "db_name"=>"test",
        "db_log"=>NP_DB_LOG_NULL
    );
    $db = new np_db_mysql_class($config);
    $db->open();
    $sql_b = new np_sql_builder("test");
    np_runtime(FALSE);
    $except_ids = array();
    for ($i=6000 ; $i<10000; $i++){

//    $id = "test.".np_guid_rand();

        $id = "test._".$i;
        $except_ids[] = $id;
    }
    $except_sql = "'".implode("','",$except_ids)."'";
    $custom_where[] = " id not in ({$except_sql}) ";


        $sql = $sql_b->where(array("age"=>"10"))->custom_where($custom_where)->query();
//var_dump($sql);die;
        $re = $db->query($sql);
        $re = $db->get_query_result();
        var_dump($re);
//        $re = $redis->hash_table("test")->hash_update($id,array("name"=>$name,"score"=>$score,"age"=>$age));
    $time = np_runtime(true);
    echo $time."s~";
    die;
}
if ($_GET["redis"] ==1)
{
    np_runtime(FALSE);
    for ($i=0 ; $i<10000; $i++){
        if ($i%1000==0)
        {
            $time = np_runtime(true);
            echo $time."s~".floor($i/1000)."\n";
            np_runtime(FALSE);
        }
        $id = "test._".$i;
        $params = array(
            "name"=>$id,
            "id"=>$id,
            "score"=>rand(0,1000),
            "age"=>rand(0,30),

        );
        $redis->set($id,serialize($params));
//        $re = $redis->hash_table("test")->hash_update($id,array("name"=>$name,"score"=>$score,"age"=>$age));
    }
    $time = np_runtime(true);
    echo $time."s~".floor($i/1000)."\n";
    die;
}

if ($_GET["redis"] ==2)
{
    np_runtime(FALSE);
    for ($i=0 ; $i<10000; $i++){
        if ($i%1000==0)
        {
            $time = np_runtime(true);
            echo $time."s~".floor($i/1000)."\n";
            np_runtime(FALSE);
        }
        $rad = rand(0,10000);
        $id = "test._".$rad;

        $redis->get($id);
//        $re = $redis->hash_table("test")->hash_update($id,array("name"=>$name,"score"=>$score,"age"=>$age));
    }
    $time = np_runtime(true);
    echo $time."s~".floor($i/1000)."\n";
    die;
}


np_runtime(FALSE);
$where =array();
//$where["#id"]="aaaaaaa";
$where["nns_public_ip"] = "127.0.0.1";
$where["nns_alive_hour"] = "127.0.0.1";
//$where["assets_type"] = 0;
//$or_where = array();
//$or_where["assets_id"] = "TVseries";
//$or_where["assets_info"] = "movie#1000001";
//$re = $redis->hash_table("test")->hash_where(array("age"=>"10"))->hash_query("*",array(0,-1));
$except_ids = array();
for ($i=6000 ; $i<10000; $i++){

//    $id = "test.".np_guid_rand();

    $id = "test._".$i;
    $except_ids[] = $id;
}
$re = $redis->hash_table("test")->hash_where(array('#id'=>'test._4'))->hash_orderby("#id")->hash_query("*",array(0,100));
var_dump($re);
$re = $redis->hash_table("test")->hash_except_where(array('#id'=>array('test._4')))->hash_orderby("#id")->hash_query("*",array(0,100));
//$re = $redis->hash_table("test")->hash_where(array("age"=>"10"))->hash_except_where(array("#id"=>$except_ids))->hash_orderby("score")->hash_query("*",array(0,10));
//$re = $redis->hash_table("test")->hash_delete();
//$re = $redis->hash_table("test")->hash_compare(array("age"=>array(3,10)))->hash_query("age,name,score",array(0,100),0,false);
//$re = $redis->hash_table("test")->hash_orderby("score")->hash_compare(array("age"=>array(5,10)))->hash_delete(array(0,-2));
//$re = $redis->hash_table("user_play_record")->hash_where($where)->hash_where($or_where,"or")->hash_query("*", array (0, 10), 0, true);
//var_dump($redis->hash_table_errors());
//$re = $redis->hash_table("test")->hash_where(array("#id"=>"test._5063","score"=>10),"or")->hash_where(array("age"=>2))->hash_count("*",array(0,100));;
//$redis->hash_table("test")->hash_update("test._1593",array("age"=>5));
//$re = $redis->get_redis()->sMembers("hash.table.index:test.age:4");
//var_dump(in_array("test._1593",$re));
//$redis->hash_table("test")->hash_where(array("#id"=>"tttt.123"))->hash_delete();
//$re = $redis->hash_table("test")->hash_destroy();
//$re = $redis->get_redis()->keys(np_redis_class::REDIS_HASH_TABLE_STRUCTURE."test");
//$redis->get_redis()->del($re);
//var_dump( $redis->get_redis()->pExpire('hash.cache:583673f701cb93c3c83f94d61ba79e39',10000));
//echo "|";
//$re = $redis->get_redis()->hKeys('hash.table.compare:*');
var_dump($re);
//var_dump($redis->hash_table("test"));
//$re=$redis->hash_table("test")->hash_destroy();
//var_dump($redis->hash_table_errors());
//$re1 = $redis->get_redis()->sMembers("hash.table.index:user_play_record.assets_type:3");
//var_dump(in_array("a2b11d373428c3d9804c35cdb604f072#156150",$re1));
//var_dump($re);
//echo $redis->get_redis()->ttl('hash.index:test.#id:2222');
//$re = $redis->hash_table_count("test");
//$re = $redis->hash_table_query("test",0,1000,"*","score","desc","test.5*");
//$re = $redis->hash_table_delete_by_where("test","test.[13]*");

//$re = $redis->hash_table_delete_by_ids("test",array("tttt.123"));
$time = np_runtime(TRUE);
echo $time;
//var_dump($redis->get_redis()->keys("*"));
//var_dump($re);